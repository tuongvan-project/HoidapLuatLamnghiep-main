// ============================================================================
// BỘ CÂU HỎI TRẮC NGHIỆM ĐÃ RÀ SOÁT, ĐỐI CHIẾU VÀ CHUẨN HÓA PHÁP LÝ
// Gói dữ liệu: Kinh doanh, chế biến lâm sản (92 câu)
// Cơ quan đối soát: Chuyên gia Pháp chế Kiểm lâm (Subagent PC)
// Căn cứ QPPL: Hệ thống QPPL hiện hành (NĐ 146/2026, NĐ 42/2026, TT 85/2025, TT 16/2025, Luật Đất đai 2024)
// Cấu trúc Object: { id, question, options, correct, explanation } (Bảo vệ tính toàn vẹn 100%)
// ============================================================================

const question_CBLS = [
  {
    "id": "CBLS_001",
    "question": "Theo Thông tư 26/2025/TT-BNNMT (hợp nhất TT 84/2025/TT-BNNMT), trường hợp nào sau đây chủ lâm sản KHÔNG BẮT BUỘC phải đề nghị cơ quan Kiểm lâm xác nhận Bảng kê lâm sản khi xuất bán?",
    "options": [
      "Doanh nghiệp chế biến gỗ được phân loại Nhóm I xuất bán sản phẩm gỗ hoặc gỗ rừng trồng hợp pháp trong nước; lâm sản là sản phẩm gỗ hoàn chỉnh",
      "Xuất bán gỗ tròn khai thác từ rừng tự nhiên trong nước",
      "Xuất bán động vật rừng nguy cấp, quý, hiếm còn sống cho cơ sở nuôi ngoại tỉnh",
      "Xuất bán gỗ xẻ thuộc Danh mục thực vật rừng Nhóm IA, IIA khai thác trong nước"
    ],
    "correct": "Doanh nghiệp chế biến gỗ được phân loại Nhóm I xuất bán sản phẩm gỗ hoặc gỗ rừng trồng hợp pháp trong nước; lâm sản là sản phẩm gỗ hoàn chỉnh",
    "explanation": "Khoản 4 Điều 5 Thông tư số 26/2025/TT-BNNMT (được sửa đổi bởi Thông tư số 84/2025/TT-BNNMT, hợp nhất tại VBHN số 04/VBHN-BNNMT): Lâm sản không phải xác nhận Bảng kê lâm sản gồm gỗ nguyên liệu của doanh nghiệp Nhóm I theo quy định của Hệ thống bảo đảm gỗ hợp pháp Việt Nam; sản phẩm gỗ (trừ trường hợp chủ lâm sản đề nghị xác nhận)."
  },
  {
    "id": "CBLS_002",
    "question": "Thời hạn cơ quan Kiểm lâm sở tại thực hiện việc xác nhận Bảng kê lâm sản đối với trường hợp KHÔNG PHẢI kiểm tra thực tế lâm sản là bao lâu?",
    "options": [
      "Trong thời hạn 02 ngày làm việc kể từ ngày nhận đủ hồ sơ đề nghị hợp lệ",
      "Trong thời hạn 24 giờ kể từ thời điểm tiếp nhận hồ sơ",
      "Trong thời hạn 05 ngày làm việc theo quy chế một cửa liên thông",
      "Trong thời hạn 07 ngày làm việc để đối chiếu với sổ theo dõi lâm sản"
    ],
    "correct": "Trong thời hạn 02 ngày làm việc kể từ ngày nhận đủ hồ sơ đề nghị hợp lệ",
    "explanation": "Điểm c Khoản 7 Điều 5 Thông tư số 26/2025/TT-BNNMT (được sửa đổi bởi Thông tư số 84/2025/TT-BNNMT, hợp nhất tại VBHN số 04/VBHN-BNNMT) quy định: Trong thời hạn 02 ngày làm việc kể từ ngày nhận được hồ sơ hợp lệ (đối với trường hợp nộp bằng bản giấy và không phải kiểm tra, xác minh thực tế lâm sản), cơ quan Kiểm lâm sở tại hoàn thành xác nhận Bảng kê lâm sản."
  },
  {
    "id": "CBLS_003",
    "question": "Trường hợp nào cơ quan Kiểm lâm BẮT BUỘC phải tiến hành kiểm tra thực tế lâm sản trước khi ký xác nhận Bảng kê lâm sản?",
    "options": [
      "Có thông tin phản ánh hoặc dấu hiệu nghi vấn lâm sản không đúng nguồn gốc, chủng loại, số lượng; hoặc lâm sản thuộc loài nguy cấp quý hiếm cần xác minh",
      "Bắt buộc đối với 100% tất cả các chuyến hàng gỗ rừng trồng xuất bán ra khỏi xã",
      "Chỉ kiểm tra khi chủ lâm sản không nộp đủ tiền lệ phí xác nhận hồ sơ",
      "Chỉ kiểm tra khi phương tiện chở hàng bị hỏng dọc đường cần cứu hộ"
    ],
    "correct": "Có thông tin phản ánh hoặc dấu hiệu nghi vấn lâm sản không đúng nguồn gốc, chủng loại, số lượng; hoặc lâm sản thuộc loài nguy cấp quý hiếm cần xác minh",
    "explanation": "Điểm c Khoản 7 Điều 5 Thông tư số 26/2025/TT-BNNMT (được sửa đổi bởi Thông tư số 84/2025/TT-BNNMT, hợp nhất tại VBHN số 04/VBHN-BNNMT): Trường hợp cần xác minh nguồn gốc lâm sản, Kiểm lâm thông báo và tiến hành xác minh trong thời hạn 02 ngày làm việc (phức tạp không quá 03 ngày làm việc) khi có dấu hiệu nghi vấn lâm sản không đúng nguồn gốc, chủng loại, số lượng hoặc lâm sản thuộc loài nguy cấp, quý, hiếm cần xác minh."
  },
  {
    "id": "CBLS_004",
    "question": "Sổ theo dõi nhập, xuất lâm sản (theo Mẫu số 04 ban hành kèm Thông tư 26/2025/TT-BNNMT) tại các cơ sở chế biến, kinh doanh gỗ phải được cập nhật như thế nào?",
    "options": [
      "Cập nhật đầy đủ, kịp thời tình hình nhập xuất lâm sản và xuất trình khi có yêu cầu kiểm tra của cơ quan có thẩm quyền",
      "Chỉ cần ghi dồn số liệu một lần vào ngày cuối cùng của mỗi tháng",
      "Ghi chép một lần vào cuối năm dương lịch khi có đoàn kiểm tra liên ngành đến làm việc",
      "Không bắt buộc phải ghi chép nếu cơ sở đã lưu trữ đầy đủ hóa đơn giá trị gia tăng"
    ],
    "correct": "Cập nhật đầy đủ, kịp thời tình hình nhập xuất lâm sản và xuất trình khi có yêu cầu kiểm tra của cơ quan có thẩm quyền",
    "explanation": "Căn cứ Điểm c Khoản 7 Điều 32 Thông tư số 26/2025/TT-BNNMT (được sửa đổi bởi Thông tư số 84/2025/TT-BNNMT, hợp nhất tại VBHN số 04/VBHN-BNNMT): Tổ chức, hộ kinh doanh phải lập Sổ theo dõi nhập, xuất lâm sản theo Mẫu số 04 Phụ lục II; cập nhật đầy đủ, kịp thời tình hình nhập xuất lâm sản và xuất trình khi có yêu cầu kiểm tra của cơ quan có thẩm quyền."
  },
  {
    "id": "CBLS_005",
    "question": "Hồ sơ nguồn gốc lâm sản hợp pháp đối với lô gỗ xẻ nhập khẩu từ quốc gia thuộc 'vùng địa lý tích cực' (không thuộc vùng rủi ro) gồm những tài liệu nào?",
    "options": [
      "Tờ khai hải quan đã thông quan, Bảng kê lâm sản nhập khẩu của chủ gỗ, Hóa đơn/chứng từ thương mại và Bảng kê lâm sản của đơn vị xuất khẩu nước ngoài",
      "Chỉ cần giấy cam kết của người lái xe chở gỗ từ cảng về xưởng mộc",
      "Chỉ cần một bức ảnh chụp công-ten-nơ gỗ tại cảng biển Hải Phòng",
      "Bắt buộc phải có Giấy phép CITES bất kể là loại gỗ keo, thông hay xoan đào"
    ],
    "correct": "Tờ khai hải quan đã thông quan, Bảng kê lâm sản nhập khẩu của chủ gỗ, Hóa đơn/chứng từ thương mại và Bảng kê lâm sản của đơn vị xuất khẩu nước ngoài",
    "explanation": "Căn cứ Điều 7 Nghị định số 102/2020/NĐ-CP (được sửa đổi, bổ sung bởi Nghị định 120/2024/NĐ-CP) và Điều 9 Thông tư số 26/2025/TT-BNNMT (hợp nhất tại VBHN số 04/VBHN-BNNMT): Gỗ nhập khẩu từ vùng an toàn (vùng địa lý tích cực) cần tờ khai hải quan đã thông quan, Bảng kê lâm sản nhập khẩu của chủ gỗ và chứng từ thương mại hợp lệ."
  },
  {
    "id": "CBLS_006",
    "question": "Theo Nghị định 102/2020/NĐ-CP (VNTLAS), trường hợp nhập khẩu loài gỗ thuộc Danh mục rủi ro hoặc từ quốc gia rủi ro, chủ gỗ bắt buộc phải bổ sung tài liệu nào?",
    "options": [
      "Tài liệu giải trình nguồn gốc gỗ hợp pháp theo Mẫu quy định (bản kê khai nguồn gốc gỗ DDS) kèm theo chứng cứ xác minh tính hợp pháp của gỗ khai thác tại nước xuất xứ",
      "Giấy xác nhận độc thân của chủ doanh nghiệp nhập khẩu gỗ",
      "Bản cam kết không bán gỗ cho các hộ gia đình đóng đồ dùng cá nhân",
      "Phiếu siêu âm kiểm tra độ ẩm bên trong giác lõi của từng lóng gỗ"
    ],
    "correct": "Tài liệu giải trình nguồn gốc gỗ hợp pháp theo Mẫu quy định (bản kê khai nguồn gốc gỗ DDS) kèm theo chứng cứ xác minh tính hợp pháp của gỗ khai thác tại nước xuất xứ",
    "explanation": "Khoản 2 Điều 7 Nghị định 102/2020/NĐ-CP quy định nhập khẩu gỗ từ vùng rủi ro bắt buộc phải có tài liệu kê khai nguồn gốc gỗ hợp pháp (DDS) và tài liệu chứng minh tính hợp pháp."
  },
  {
    "id": "CBLS_007",
    "question": "Hành vi vận chuyển gỗ rừng trồng hợp pháp nhưng không mang theo Bảng kê lâm sản hoặc hồ sơ nguồn gốc trong quá trình lưu thông bị xử phạt về hành vi nào?",
    "options": [
      "Hành vi vi phạm quy định về quản lý hồ sơ lâm sản trong vận chuyển lâm sản",
      "Tự động bị coi là hành vi buôn lậu gỗ tự nhiên và bị tịch thu toàn bộ xe ô tô",
      "Hành vi vi phạm quy tắc an toàn giao thông đường bộ do Bộ GTVT xử phạt",
      "Không bị xử phạt nếu tài xế xuất trình được căn cước công dân gắn chíp"
    ],
    "correct": "Hành vi vi phạm quy định về quản lý hồ sơ lâm sản trong vận chuyển lâm sản",
    "explanation": "Căn cứ Điều 27 Nghị định số 146/2026/NĐ-CP: Trường hợp lâm sản có nguồn gốc hợp pháp nhưng không mang theo hoặc xuất trình chậm hồ sơ theo quy định thì bị xử phạt vi phạm hành chính về quản lý hồ sơ lâm sản."
  },
  {
    "id": "CBLS_008",
    "question": "Hành vi tàng trữ gỗ quý hiếm Nhóm IA không có hồ sơ nguồn gốc hợp pháp tại kho xưởng cưa xẻ với khối lượng tối thiểu bao nhiêu thì bị khởi tố hình sự theo Điều 232 BLHS?",
    "options": [
      "Từ 1,5 m³ gỗ trở lên (khung hình phạt cải tạo không giam giữ đến 03 năm hoặc phạt tù từ 06 tháng đến 03 năm)",
      "Từ 10 m³ gỗ tròn trở lên mới cấu thành tội phạm hình sự",
      "Từ 50 m³ gỗ tròn trở lên mới bị xử lý hình sự",
      "Không bao giờ bị đi tù nếu tàng trữ gỗ trong khuôn viên đất ở của gia đình"
    ],
    "correct": "Từ 1,5 m³ gỗ trở lên (khung hình phạt cải tạo không giam giữ đến 03 năm hoặc phạt tù từ 06 tháng đến 03 năm)",
    "explanation": "Căn cứ Điểm k Khoản 1 Điều 232 Bộ luật Hình sự năm 2015: Hành vi tàng trữ, vận chuyển, chế biến hoặc mua bán trái phép từ 1,5 m³ đến dưới 03 m³ gỗ thuộc Danh mục loài nguy cấp, quý, hiếm được ưu tiên bảo vệ hoặc Nhóm IA bị truy cứu trách nhiệm hình sự với khung hình phạt tiền từ 50 đến 300 triệu đồng, phạt cải tạo không giam giữ đến 03 năm hoặc phạt tù từ 06 tháng đến 03 năm."
  },
  {
    "id": "CBLS_009",
    "question": "Đối với gỗ thông thường (không thuộc loài nguy cấp, quý, hiếm), hành vi vận chuyển trái pháp luật đạt khối lượng tối thiểu bao nhiêu thì bị truy cứu trách nhiệm hình sự theo Điều 232 BLHS?",
    "options": [
      "Từ 20 m³ gỗ trở lên",
      "Từ 2 m³ gỗ tròn trở lên trong mọi trường hợp",
      "Phải từ 100 m³ gỗ tròn trở lên mới cấu thành tội phạm",
      "Gỗ thông thường chỉ bị xử phạt tiền tối đa 50 triệu đồng, không bị hình sự"
    ],
    "correct": "Từ 20 m³ gỗ trở lên",
    "explanation": "Căn cứ Điểm k Khoản 1 Điều 232 Bộ luật Hình sự năm 2015: Hành vi tàng trữ, vận chuyển, chế biến hoặc mua bán trái phép từ 20 m³ đến dưới 40 m³ gỗ loài thực vật rừng thông thường bị truy cứu trách nhiệm hình sự với khung hình phạt từ 06 tháng đến 03 năm tù giam."
  },
  {
    "id": "CBLS_010",
    "question": "Chủ cơ sở chế biến gỗ mua gom gỗ trôi nổi của các đối tượng đào trộm trên rừng tự nhiên về cưa xẻ, sau đó dùng hóa đơn khống để hợp thức hóa bị coi là hành vi gì?",
    "options": [
      "Hành vi tàng trữ, chế biến lâm sản trái pháp luật và gian lận hồ sơ lâm sản; có thể bị truy cứu hình sự về tội vi phạm quy định lâm sản và tội trốn thuế",
      "Nghiệp vụ quay vòng hóa đơn thương mại được cơ quan thuế chấp thuận",
      "Biện pháp linh hoạt hỗ trợ người nghèo vùng sâu vùng xa tiêu thụ gỗ",
      "Hoạt động sản xuất kinh doanh thông thường không vi phạm pháp luật"
    ],
    "correct": "Hành vi tàng trữ, chế biến lâm sản trái pháp luật và gian lận hồ sơ lâm sản; có thể bị truy cứu hình sự về tội vi phạm quy định lâm sản và tội trốn thuế",
    "explanation": "Căn cứ Điều 232 và Điều 200 Bộ luật Hình sự năm 2015 (sửa đổi, bổ sung 2017): Mua gỗ lậu rồi dùng hóa đơn bất hợp pháp để hợp thức hóa cấu thành tội phạm lâm sản và tội trốn thuế."
  },
  {
    "id": "CBLS_011",
    "question": "Phương pháp tính khối lượng gỗ tròn có đường kính đầu nhỏ từ 06 cm đến dưới 20 cm và chiều dài từ 01 mét trở lên (gỗ tròn nhỏ) theo Thông tư 26 là gì?",
    "options": [
      "Đo đường kính đầu nhỏ và chiều dài để tra Bảng khối lượng gỗ tròn hoặc tính theo công thức thể tích hình nón cụt/hình trụ quy định tại Phụ lục I",
      "Chỉ cân trọng lượng tấn rồi quy đổi tương đương 1 tấn bằng 1 mét khối gỗ",
      "Đo chu vi của cả bó củi rồi chia đều cho số lượng cây trong bó",
      "Ước lượng bằng mắt thường của cán bộ kiểm lâm địa bàn"
    ],
    "correct": "Đo đường kính đầu nhỏ và chiều dài để tra Bảng khối lượng gỗ tròn hoặc tính theo công thức thể tích hình nón cụt/hình trụ quy định tại Phụ lục I",
    "explanation": "Phụ lục I Thông tư 26/2025/TT-BNNMT hướng dẫn chi tiết phương pháp đo đường kính đầu nhỏ d (cm), chiều dài L (m) để tính thể tích hoặc tra bảng khối lượng gỗ tròn nhỏ."
  },
  {
    "id": "CBLS_012",
    "question": "Khi kiểm tra lâm sản tại xưởng mộc, sự sai lệch (dung sai) giữa khối lượng gỗ xẻ thực tế so với khối lượng ghi trên hồ sơ Bảng kê lâm sản trong giới hạn nào thì KHÔNG bị coi là vi phạm?",
    "options": [
      "Sai lệch không vượt quá 5% về tổng thể tích hoặc sai số kỹ thuật đo đếm trong giới hạn cho phép theo quy chuẩn",
      "Được phép sai lệch lên tới 50% tổng thể tích lô gỗ",
      "Tuyệt đối không được sai lệch dù chỉ 0,0001 mét khối gỗ",
      "Được phép thừa thiếu bao nhiêu cũng được nếu cùng chủng loại gỗ"
    ],
    "correct": "Sai lệch không vượt quá 5% về tổng thể tích hoặc sai số kỹ thuật đo đếm trong giới hạn cho phép theo quy chuẩn",
    "explanation": "Căn cứ Điểm d Khoản 2 Mục II Phụ lục I ban hành kèm theo Thông tư số 26/2025/TT-BNNMT (hợp nhất tại VBHN số 04/VBHN-BNNMT): Sai số tính thể tích gỗ trong mỗi lần đo đối với từng thanh, tấm, hộp gỗ xẻ, đẽo cho phép là năm phần trăm (±5%)."
  },
  {
    "id": "CBLS_013",
    "question": "Toàn bộ hồ sơ nguồn gốc lâm sản và Sổ theo dõi nhập xuất lâm sản tại xưởng chế biến gỗ bắt buộc phải lưu trữ trong thời hạn tối thiểu bao lâu?",
    "options": [
      "Tối thiểu 05 năm kể từ ngày xuất bán hết toàn bộ lô lâm sản",
      "Tối thiểu 06 tháng kể từ ngày hoàn thành hợp đồng mua bán",
      "Chỉ cần lưu đến khi kết thúc năm tài chính hiện hành",
      "Không cần lưu nếu cơ sở đã chuyển đổi sang mô hình công ty cổ phần"
    ],
    "correct": "Tối thiểu 05 năm kể từ ngày xuất bán hết toàn bộ lô lâm sản",
    "explanation": "Căn cứ Điểm b Khoản 5 Điều 27 Nghị định số 102/2020/NĐ-CP (được sửa đổi, bổ sung bởi Nghị định 120/2024/NĐ-CP) và Khoản 7 Điều 32 Thông tư số 26/2025/TT-BNNMT: Chủ lâm sản có trách nhiệm lưu giữ hồ sơ gỗ trong thời hạn 05 năm kể từ ngày xuất bán gỗ phục vụ kiểm tra, truy xuất nguồn gốc."
  },
  {
    "id": "CBLS_014",
    "question": "Hành vi sử dụng búa bài cây hoặc dấu búa Kiểm lâm giả để đóng lên cây gỗ nhằm hợp thức hóa nguồn gốc lâm sản bị xử lý thế nào?",
    "options": [
      "Bị xử lý hình sự về Tội làm giả con dấu, tài liệu của cơ quan, tổ chức và tịch thu toàn bộ tang vật, gỗ vi phạm",
      "Chỉ bị phạt vi phạm hành chính mức 5.000.000 đồng về hành vi khắc dấu sai quy định",
      "Được coi là sự sáng tạo trong công tác quản lý của chủ doanh nghiệp",
      "Chỉ bị tịch thu cây búa giả mà không bị phạt tiền"
    ],
    "correct": "Bị xử lý hình sự về Tội làm giả con dấu, tài liệu của cơ quan, tổ chức và tịch thu toàn bộ tang vật, gỗ vi phạm",
    "explanation": "Căn cứ Điều 341 và Điều 232 Bộ luật Hình sự năm 2015: Làm giả và sử dụng dấu búa Kiểm lâm giả là hành vi phạm tội hình sự nghiêm trọng (phạt tù đến 7 năm) và tịch thu toàn bộ tang vật."
  },
  {
    "id": "CBLS_015",
    "question": "Trường hợp gỗ thành phẩm được chế biến từ gỗ có nguồn gốc hợp pháp, khi vận chuyển xuất bán cho người tiêu dùng nội tỉnh cần hồ sơ gì?",
    "options": [
      "Hóa đơn theo quy định của Bộ Tài chính kèm Bảng kê lâm sản do chủ lâm sản tự lập (không cần Kiểm lâm xác nhận)",
      "Bắt buộc phải có Giấy xác nhận của Chi cục trưởng Chi cục Kiểm lâm cấp tỉnh",
      "Phải có Giấy kiểm dịch thực vật của Cục Bảo vệ thực vật",
      "Chỉ cần người mua tự ký vào một tờ giấy trắng cam kết tự chịu trách nhiệm"
    ],
    "correct": "Hóa đơn theo quy định của Bộ Tài chính kèm Bảng kê lâm sản do chủ lâm sản tự lập (không cần Kiểm lâm xác nhận)",
    "explanation": "Căn cứ Khoản 4 Điều 5 và Điều 11 Thông tư số 26/2025/TT-BNNMT (hợp nhất tại VBHN số 04/VBHN-BNNMT): Sản phẩm gỗ hoàn chỉnh không phải xác nhận Bảng kê lâm sản; khi lưu thông nội địa chỉ cần hóa đơn hoặc chứng từ bán hàng hợp pháp kèm Bảng kê lâm sản do chủ hàng tự lập."
  },
  {
    "id": "CBLS_016",
    "question": "Cơ sở cưa xẻ gỗ hoạt động chế biến, cưa xe gỗ mà không có nguồn gốc hợp pháp hoặc có nguồn gốc hợp pháp nhưng không có hồ sơ lâm sản thì bị xử phạt như thế nào?",
    "options": [
      "Bị xử phạt về hành vi chế biến lâm sản trái pháp luật hoặc Vi phạm quy định về quản lý hồ sơ lâm sản trong chế biến lâm sản",
      "Do là xưởng cưa xẻ và không phải là gỗ của xưởng xẻ nên không bị xử phạt, chỉ xử phạt với chủ gỗ",
      "Được cấp phép tự động sau khi nộp tiền phạt 500.000 đồng",
      "Không bị kiểm tra vì nằm trên đất thổ cư thuộc quyền sử dụng hợp pháp của chủ nhà"
    ],
    "correct": "Bị xử phạt về hành vi chế biến lâm sản trái pháp luật hoặc Vi phạm quy định về quản lý hồ sơ lâm sản trong chế biến lâm sản",
    "explanation": "Căn cứ Điều 26 và 27 Nghị định số 146/2026/NĐ-CP ngày 06/5/2026 quy định xử phạt vi phạm hành chính trong lĩnh vực lâm nghiệp."
  },
  {
    "id": "CBLS_017",
    "question": "Đối với gỗ tròn nhập khẩu còn nguyên vỏ từ nước ngoài về Việt Nam, biện pháp kiểm dịch bắt buộc trước khi đưa vào chế biến là gì?",
    "options": [
      "Kiểm dịch thực vật tại cửa khẩu nhập và xử lý hun trùng khử trùng nấm, bọ vòi voi, côn trùng gây hại theo quy định kiểm dịch thực vật",
      "Rửa sạch bằng nước xà phòng công nghiệp tại kho của nhà máy",
      "Phơi nắng liên tục 15 ngày trên bãi cỏ không cần hun trùng",
      "Chỉ kiểm dịch nếu nhập khẩu gỗ từ các quốc gia ở Châu Phi"
    ],
    "correct": "Kiểm dịch thực vật tại cửa khẩu nhập và xử lý hun trùng khử trùng nấm, bọ vòi voi, côn trùng gây hại theo quy định kiểm dịch thực vật",
    "explanation": "Căn cứ Điều 26 Luật Bảo vệ và kiểm dịch thực vật năm 2013: Gỗ tròn nhập khẩu chưa bóc vỏ bắt buộc phải kiểm dịch và xử lý hun trùng nghiêm ngặt ngăn ngừa sinh vật ngoại lai gây hại."
  },
  {
    "id": "CBLS_018",
    "question": "Cơ sở chế biến gỗ mua gỗ rừng trồng của người dân nhưng không lập Bảng kê lâm sản mà tự xuất bán cho nhà máy dăm gỗ bị xử phạt như thế nào?",
    "options": [
      "Bị xử phạt vi phạm hành chính về hành vi không lập hồ sơ lâm sản hợp pháp khi mua bán lâm sản",
      "Được miễn xử phạt nếu gỗ keo trồng đã đủ 5 năm tuổi",
      "Chỉ bị phạt tiền nếu nhà máy dăm gỗ khiếu nại lên cơ quan công an",
      "Bị coi là tội phạm phá rừng tự nhiên và bị khởi tố hình sự"
    ],
    "correct": "Bị xử phạt vi phạm hành chính về hành vi không lập hồ sơ lâm sản hợp pháp khi mua bán lâm sản",
    "explanation": "Căn cứ Điều 27 Nghị định số 146/2026/NĐ-CP: Không lập Bảng kê lâm sản khi mua bán, giao nhận lâm sản cấu thành hành vi vi phạm quy định về quản lý hồ sơ lâm sản hợp pháp."
  },
  {
    "id": "CBLS_019",
    "question": "Hành vi cố ý khai sai tên loài cây gỗ trong Bảng kê lâm sản (ví dụ ghi gỗ keo nhưng thực tế là gỗ nghiến rừng tự nhiên) bị pháp luật xử lý thế nào?",
    "options": [
      "Bị xử lý nghiêm về hành vi gian lận hồ sơ lâm sản, buôn bán tàng trữ lâm sản trái pháp luật và bị tịch thu toàn bộ số gỗ nghiến vi phạm",
      "Được coi là sự nhầm lẫn kỹ thuật và chỉ cần lấy bút gạch đi viết lại tên loài gỗ",
      "Chỉ bị phạt cảnh cáo nếu chủ xe đồng ý nộp tiền bốc vác cho tổ kiểm tra",
      "Được tiếp tục vận chuyển nếu tài xế chở kèm theo một cành lá cây keo làm mẫu"
    ],
    "correct": "Bị xử lý nghiêm về hành vi gian lận hồ sơ lâm sản, buôn bán tàng trữ lâm sản trái pháp luật và bị tịch thu toàn bộ số gỗ nghiến vi phạm",
    "explanation": "Căn cứ Điều 26 Nghị định số 146/2026/NĐ-CP và Điều 232 Bộ luật Hình sự năm 2015: Kê khai gian dối tên loài gỗ để hợp thức hóa gỗ quý hiếm bị xử lý về hành vi tàng trữ lâm sản trái phép và tịch thu toàn bộ tang vật."
  },
  {
    "id": "CBLS_020",
    "question": "Khi gỗ tròn tự nhiên khai thác tận thu từ công trình giải phóng mặt bằng được bán đấu giá tài sản công, hồ sơ lưu thông gồm những gì?",
    "options": [
      "Hóa đơn bán tài sản công (hoặc hóa đơn GTGT), Quyết định phê duyệt kết quả trúng đấu giá và Bảng kê lâm sản có xác nhận của Kiểm lâm sở tại",
      "Chỉ cần biên lai thu tiền của người trúng đấu giá",
      "Chỉ cần hợp đồng đặt cọc giữa bên mua và bên bán đấu giá",
      "Bản photocopy thông báo mời thầu đăng trên báo điện tử"
    ],
    "correct": "Hóa đơn bán tài sản công (hoặc hóa đơn GTGT), Quyết định phê duyệt kết quả trúng đấu giá và Bảng kê lâm sản có xác nhận của Kiểm lâm sở tại",
    "explanation": "Căn cứ Điều 10 và Điều 11 Thông tư số 26/2025/TT-BNNMT (hợp nhất tại VBHN số 04/VBHN-BNNMT): Lâm sản có nguồn gốc sau xử lý tài sản công khi bán, lưu thông phải có Hóa đơn bán tài sản công (hoặc hóa đơn GTGT), Quyết định phê duyệt phương án xử lý/kết quả bán đấu giá và Bảng kê lâm sản hợp lệ."
  },
  {
    "id": "CBLS_021",
    "question": "Hành vi đổ mạt cưa, mùn cưa và phế phẩm vỏ cây xuống dòng sông, suối gây tắc nghẽn dòng chảy và ô nhiễm nguồn nước bị xử lý ra sao?",
    "options": [
      "Bị xử phạt nặng về hành vi vi phạm pháp luật bảo vệ môi trường, buộc vớt toàn bộ mùn cưa khôi phục hiện trạng dòng chảy và bồi thường thiệt hại",
      "Được coi là hoạt động xả thải tự nhiên làm giàu chất hữu cơ cho tôm cá",
      "Chỉ bị xử phạt nếu lượng mùn cưa trôi vào ao nuôi cá của hộ liền kề",
      "Không bị kiểm tra xử lý vì mùn cưa là chất dễ phân hủy tự nhiên"
    ],
    "correct": "Bị xử phạt nặng về hành vi vi phạm pháp luật bảo vệ môi trường, buộc vớt toàn bộ mùn cưa khôi phục hiện trạng dòng chảy và bồi thường thiệt hại",
    "explanation": "Căn cứ Điều 19 và Điều 23 Nghị định số 45/2022/NĐ-CP: Xả chất thải rắn công nghiệp (mùn cưa, vỏ cây) vào nguồn nước vi phạm nghiêm trọng Luật Bảo vệ môi trường, bị phạt tiền và buộc nạo vét dòng chảy."
  },
  {
    "id": "CBLS_022",
    "question": "Chủ phương tiện khi vận chuyển gỗ tròn, gỗ xẻ trên đường BẮT BUỘC phải mang theo giấy tờ gì?",
    "options": [
      "Bản chính hoặc bản điện tử Bảng kê lâm sản hợp pháp kèm hóa đơn/hồ sơ nguồn gốc lâm sản",
      "Chỉ cần mang theo sổ đăng kiểm xe ô tô",
      "Chỉ cần giấy cam đoan miệng với chủ hàng",
      "Không cần mang theo bất kỳ giấy tờ lâm sản nào"
    ],
    "correct": "Bản chính hoặc bản điện tử Bảng kê lâm sản hợp pháp kèm hóa đơn/hồ sơ nguồn gốc lâm sản",
    "explanation": "Căn cứ Điều 11 Thông tư số 26/2025/TT-BNNMT (hợp nhất tại VBHN số 04/VBHN-BNNMT) và Điều 27 Nghị định số 146/2026/NĐ-CP: Khi vận chuyển lâm sản, người điều khiển phương tiện phải mang theo hồ sơ lâm sản hợp pháp gồm bản chính hoặc bản điện tử Bảng kê lâm sản kèm hóa đơn/hồ sơ nguồn gốc để xuất trình khi kiểm tra."
  },
  {
    "id": "CBLS_023",
    "question": "Xưởng cưa xẻ, chế biến gỗ muốn hoạt động hợp pháp phải đáp ứng điều kiện thủ tục gì đầu tiên?",
    "options": [
      "Đăng ký kinh doanh ngành nghề chế biến gỗ, có hồ sơ môi trường và phương án PCCC được phê duyệt",
      "Chỉ cần mua máy cưa về đặt ngoài vườn là được cưa",
      "Chỉ cần xin phép Trưởng thôn bằng miệng",
      "Không cần đăng ký kinh doanh nếu quy mô nhỏ"
    ],
    "correct": "Đăng ký kinh doanh ngành nghề chế biến gỗ, có hồ sơ môi trường và phương án PCCC được phê duyệt",
    "explanation": "Căn cứ Điều 8 Nghị định số 102/2020/NĐ-CP và Nghị định số 01/2021/NĐ-CP: Cơ sở chế biến gỗ phải có đăng ký kinh doanh, chấp hành quy định an toàn PCCC, bảo vệ môi trường và nguồn gốc lâm sản hợp pháp."
  },
  {
    "id": "CBLS_024",
    "question": "Cơ quan nào có thẩm quyền tiếp nhận hồ sơ và quyết định phân loại Doanh nghiệp chế biến gỗ (Nhóm I, Nhóm II)?",
    "options": [
      "Cơ quan Kiểm lâm cấp tỉnh (Chi cục Kiểm lâm)",
      "Ủy ban nhân dân cấp xã",
      "Hiệp hội Gỗ và Lâm sản Việt Nam",
      "Cục Cảnh sát giao thông"
    ],
    "correct": "Cơ quan Kiểm lâm cấp tỉnh (Chi cục Kiểm lâm)",
    "explanation": "Căn cứ Khoản 2 Điều 13 Nghị định số 102/2020/NĐ-CP (được sửa đổi, bổ sung bởi Nghị định số 120/2024/NĐ-CP và Nghị định số 42/2026/NĐ-CP): Cơ quan Kiểm lâm cấp tỉnh là cơ quan tiếp nhận đăng ký và thực hiện phân loại Doanh nghiệp chế biến, xuất khẩu gỗ."
  },
  {
    "id": "CBLS_025",
    "question": "Khi lâm sản vận chuyển mà không thay đổi chủ sở hữu và không đổi khối lượng thì có được dùng chung 1 Bảng kê không?",
    "options": [
      "Được sử dụng cùng một Bảng kê lâm sản đi suốt tuyến đường vận chuyển",
      "Mỗi xã đi qua phải lập một Bảng kê mới",
      "Cứ mỗi 10 km phải lập lại Bảng kê mới",
      "Không được phép dùng chung"
    ],
    "correct": "Được sử dụng cùng một Bảng kê lâm sản đi suốt tuyến đường vận chuyển",
    "explanation": "Căn cứ Khoản 2 Điều 5 Thông tư số 26/2025/TT-BNNMT (được sửa đổi, bổ sung bởi Thông tư số 84/2025/TT-BNNMT): Trường hợp lâm sản được vận chuyển mà không có thay đổi về chủ sở hữu và khối lượng, số lượng trong Bảng kê lâm sản thì được sử dụng cùng một Bảng kê lâm sản."
  },
  {
    "id": "CBLS_026",
    "question": "Chủ lâm sản chịu trách nhiệm như thế nào về những nội dung kê khai trong Bảng kê lâm sản?",
    "options": [
      "Không phải chịu trách nhiệm vì do lái xe khai hộ",
      "Chịu trách nhiệm hoàn toàn trước pháp luật về tính chính xác và tính hợp pháp của nội dung kê khai",
      "Nếu khai sai thì Kiểm lâm phải chịu trách nhiệm thay",
      "Chỉ chịu trách nhiệm 50%"
    ],
    "correct": "Chịu trách nhiệm hoàn toàn trước pháp luật về tính chính xác và tính hợp pháp của nội dung kê khai",
    "explanation": "Căn cứ Khoản 2 Điều 5 Thông tư số 26/2025/TT-BNNMT (được sửa đổi, bổ sung bởi Thông tư số 84/2025/TT-BNNMT): Chủ lâm sản chịu trách nhiệm trước pháp luật về tính hợp pháp và tính chính xác của những nội dung kê khai tại Bảng kê lâm sản."
  },
  {
    "id": "CBLS_027",
    "question": "Cơ sở cưa xẻ gỗ có trách nhiệm báo cáo tình hình nhập, xuất lâm sản định kỳ cho ai?",
    "options": [
      "Báo cáo định kỳ bằng văn bản cho cơ quan Kiểm lâm sở tại (Hạt Kiểm lâm)",
      "Báo cáo cho Đài truyền hình địa phương",
      "Chỉ báo cáo khi có Kiểm lâm đến kiểm tra",
      "Không phải báo cáo định kỳ"
    ],
    "correct": "Báo cáo định kỳ bằng văn bản cho cơ quan Kiểm lâm sở tại (Hạt Kiểm lâm)",
    "explanation": "Căn cứ Điểm c Khoản 7 Điều 32 Thông tư số 26/2025/TT-BNNMT (được sửa đổi, bổ sung bởi Thông tư số 84/2025/TT-BNNMT): Cơ sở cưa xẻ, chế biến gỗ có trách nhiệm báo cáo tình hình nhập, xuất lâm sản cho cơ quan Kiểm lâm sở tại theo Mẫu số 29 định kỳ hằng năm trước ngày 15 tháng 01."
  },
  {
    "id": "CBLS_028",
    "question": "Đối với lô gỗ nhập khẩu mua lại từ doanh nghiệp khác, cơ sở chế biến cần lưu giữ chứng từ gì?",
    "options": [
      "Hóa đơn GTGT, Bảng kê lâm sản của người bán và bản sao tờ khai hải quan nhập khẩu",
      "Chỉ cần tờ giấy ghi nợ tiền gỗ",
      "Chỉ cần tin nhắn thỏa thuận giá trên Zalo",
      "Không cần chứng từ gì nếu đã trả đủ tiền"
    ],
    "correct": "Hóa đơn GTGT, Bảng kê lâm sản của người bán và bản sao tờ khai hải quan nhập khẩu",
    "explanation": "Căn cứ Điều 9 Thông tư số 26/2025/TT-BNNMT (được sửa đổi, bổ sung bởi Thông tư số 84/2025/TT-BNNMT): Gỗ nhập khẩu mua lại từ doanh nghiệp khác phải lưu giữ hồ sơ gồm Bảng kê lâm sản của chủ lâm sản bán, hóa đơn theo quy định của Bộ Tài chính và bản sao tờ khai hải quan thông quan của lô gỗ gốc."
  },
  {
    "id": "CBLS_029",
    "question": "Trường hợp nào cơ sở chế biến gỗ bị đưa vào danh sách Doanh nghiệp Nhóm II (nhóm rủi ro)?",
    "options": [
      "Doanh nghiệp không đáp ứng tiêu chuẩn tuân thủ pháp luật hoặc có hành vi gian lận hồ sơ lâm sản",
      "Doanh nghiệp nộp thuế quá sớm",
      "Doanh nghiệp có nhiều công nhân giỏi",
      "Doanh nghiệp mở thêm chi nhánh mới"
    ],
    "correct": "Doanh nghiệp không đáp ứng tiêu chuẩn tuân thủ pháp luật hoặc có hành vi gian lận hồ sơ lâm sản",
    "explanation": "Căn cứ Điều 12 và Điều 14 Nghị định số 102/2020/NĐ-CP (sửa đổi bởi Nghị định số 120/2024/NĐ-CP và Nghị định số 42/2026/NĐ-CP): Doanh nghiệp không đáp ứng tiêu chí Doanh nghiệp Nhóm I hoặc có hành vi vi phạm pháp luật lâm nghiệp, hải quan sẽ bị xếp loại hoặc chuyển loại sang Doanh nghiệp Nhóm II."
  },
  {
    "id": "CBLS_030",
    "question": "Khi bán lẻ gỗ cho người dân làm nhà ở, cơ sở kinh doanh gỗ phải lập giấy tờ gì giao cho người mua?",
    "options": [
      "Lập Bảng kê lâm sản và xuất hóa đơn theo quy định của pháp luật thuế",
      "Chỉ cần viết giấy tay biên nhận tiền",
      "Không cần giao bất kỳ giấy tờ gì",
      "Yêu cầu người mua tự lên xã xin giấy phép"
    ],
    "correct": "Lập Bảng kê lâm sản và xuất hóa đơn theo quy định của pháp luật thuế",
    "explanation": "Căn cứ Khoản 1 Điều 5 và Điều 11 Thông tư số 26/2025/TT-BNNMT (hợp nhất tại VBHN số 04/VBHN-BNNMT): Khi bán lâm sản trong nước, chủ lâm sản phải lập Bảng kê lâm sản và giao hóa đơn theo quy định của Bộ Tài chính cho người mua để lưu thông hợp pháp."
  },
  {
    "id": "CBLS_031",
    "question": "Hồ sơ lâm sản điện tử có giá trị pháp lý tương đương hồ sơ giấy không?",
    "options": [
      "Không có giá trị gì",
      "Có giá trị pháp lý tương đương hồ sơ bản giấy nếu được lập, xác thực chữ ký số theo đúng quy định",
      "Chỉ có giá trị nếu in ra giấy rồi đóng dấu đỏ đè lên",
      "Chỉ có giá trị khi gửi qua bưu điện"
    ],
    "correct": "Có giá trị pháp lý tương đương hồ sơ bản giấy nếu được lập, xác thực chữ ký số theo đúng quy định",
    "explanation": "Căn cứ Thông tư số 26/2025/TT-BNNMT (được sửa đổi bởi Thông tư số 84/2025/TT-BNNMT) và Luật Giao dịch điện tử: Hồ sơ lâm sản điện tử có giá trị pháp lý tương đương hồ sơ bản giấy khi đáp ứng đầy đủ điều kiện về lập, ký số và quản lý theo quy định."
  },
  {
    "id": "CBLS_032",
    "question": "Thủ tục đề nghị cấp giấy phép CITES xuất khẩu gỗ quý hiếm được nộp tại cơ quan nào?",
    "options": [
      "Cơ quan quản lý CITES Việt Nam (thuộc Cục Lâm nghiệp và Kiểm lâm)",
      "Ủy ban nhân dân cấp xã nơi đặt xưởng gỗ",
      "Hạt Kiểm lâm khu vực",
      "Chi cục Hải quan cửa khẩu"
    ],
    "correct": "Cơ quan quản lý CITES Việt Nam (thuộc Cục Lâm nghiệp và Kiểm lâm)",
    "explanation": "Căn cứ Điều 28, Điều 29 và Điều 34 Thông tư số 85/2025/TT-BNNMT: Cơ quan có thẩm quyền cấp Giấy phép CITES xuất khẩu mẫu vật động vật, thực vật hoang dã nguy cấp là Cơ quan thẩm quyền quản lý CITES Việt Nam (thuộc Cục Lâm nghiệp và Kiểm lâm)."
  },
  {
    "id": "CBLS_033",
    "question": "Chủ cơ sở chế biến gỗ có nghĩa vụ gì khi cơ quan Kiểm lâm đến kiểm tra định kỳ hoặc đột xuất?",
    "options": [
      "Đóng cửa xưởng bỏ trốn hoặc thả chó đuổi cán bộ",
      "Xuất trình đầy đủ hồ sơ nguồn gốc lâm sản, sổ theo dõi và tạo điều kiện cho đoàn kiểm tra",
      "Chỉ tiếp đoàn kiểm tra nếu có báo trước 1 tháng",
      "Yêu cầu đoàn kiểm tra phải nộp phí kiểm tra"
    ],
    "correct": "Xuất trình đầy đủ hồ sơ nguồn gốc lâm sản, sổ theo dõi và tạo điều kiện cho đoàn kiểm tra",
    "explanation": "Căn cứ Điểm b, Điểm c Khoản 7 Điều 32 Thông tư số 26/2025/TT-BNNMT kết hợp với quyền kiểm tra của Kiểm lâm tại Điều 104 Luật Lâm nghiệp 2017 và nghĩa vụ chấp hành kiểm tra của cơ sở chế biến tại Điều 69, Điều 72 Luật Lâm nghiệp 2017."
  },
  {
    "id": "CBLS_034",
    "question": "Biện pháp phòng cháy chữa cháy bắt buộc tại các xưởng cưa xẻ, chế biến gỗ là gì?",
    "options": [
      "Trang bị bình chữa cháy, bể nước cát, tiêu lệnh PCCC và dọn dẹp mùn cưa, dăm gỗ thường xuyên",
      "Chỉ cần dán khẩu hiệu trên tường",
      "Để công nhân hút thuốc tự do trong xưởng",
      "Tích trữ nhiều can xăng cạnh đống mùn cưa"
    ],
    "correct": "Trang bị bình chữa cháy, bể nước cát, tiêu lệnh PCCC và dọn dẹp mùn cưa, dăm gỗ thường xuyên",
    "explanation": "Căn cứ Điều 47 Nghị định số 156/2018/NĐ-CP và Luật Phòng cháy và chữa cháy: Cơ sở chế biến gỗ bắt buộc phải thực hiện các biện pháp an toàn PCCC, trang bị phương tiện, dụng cụ dập lửa và định kỳ dọn sạch mùn cưa, vật liệu dễ cháy."
  },
  {
    "id": "CBLS_035",
    "question": "Mùn cưa, vỏ cây, phế liệu gỗ tại cơ sở chế biến phải được xử lý như thế nào để bảo vệ môi trường?",
    "options": [
      "Đem đổ trộm xuống sông suối gần xưởng",
      "Thu gom xử lý làm viên nén, phân bón hoặc đốt tiêu hủy đúng nơi quy định an toàn",
      "Châm lửa đốt lộ thiên giữa trời khói bụi mù mịt",
      "Đổ bừa bãi lấn chiếm hành lang an toàn giao thông"
    ],
    "correct": "Thu gom xử lý làm viên nén, phân bón hoặc đốt tiêu hủy đúng nơi quy định an toàn",
    "explanation": "Căn cứ Luật Bảo vệ môi trường năm 2020 và Nghị định số 45/2022/NĐ-CP: Mùn cưa, vỏ cây, phế phẩm xưởng gỗ phải được thu gom, tái chế hoặc xử lý đúng quy định về chất thải rắn công nghiệp thông thường; nghiêm cấm xả thải bừa bãi gây ô nhiễm môi trường."
  },
  {
    "id": "CBLS_036",
    "question": "Khi phát hiện gỗ mua vào có dấu hiệu là gỗ khai thác lậu từ rừng tự nhiên, chủ xưởng gỗ nên làm gì?",
    "options": [
      "Nhanh chóng cưa xẻ nhỏ để phi tang tang vật",
      "Từ chối thu mua và báo ngay cho cơ quan Kiểm lâm hoặc Công an sở tại để xử lý",
      "Ép giá người bán thật rẻ rồi giấu vào kho kín",
      "Đem đi bán lại cho xưởng gỗ khác"
    ],
    "correct": "Từ chối thu mua và báo ngay cho cơ quan Kiểm lâm hoặc Công an sở tại để xử lý",
    "explanation": "Căn cứ Điều 9 Luật Lâm nghiệp 2017 (Các hành vi bị nghiêm cấm trong hoạt động lâm nghiệp), Điều 26 Nghị định số 146/2026/NĐ-CP và nguyên tắc tố giác vi phạm theo quy định pháp luật phòng chống tội phạm và vi phạm pháp luật."
  },
  {
    "id": "CBLS_037",
    "question": "Chủ phương tiện vận tải có trách nhiệm gì trước khi nhận chở một chuyến gỗ trên đường?",
    "options": [
      "Chỉ cần quan tâm người thuê trả bao nhiêu tiền cước",
      "Kiểm tra tính hợp lệ của Bảng kê lâm sản, hóa đơn kèm theo và đối chiếu với số lượng gỗ thực tế trên xe",
      "Cứ chở bừa, bị bắt thì đổ hết tội cho chủ hàng",
      "Chỉ chở vào ban đêm để tránh trạm kiểm soát"
    ],
    "correct": "Kiểm tra tính hợp lệ của Bảng kê lâm sản, hóa đơn kèm theo và đối chiếu với số lượng gỗ thực tế trên xe",
    "explanation": "Căn cứ Điều 25 Nghị định số 146/2026/NĐ-CP: Lái xe, chủ phương tiện vận tải có trách nhiệm kiểm tra hồ sơ lâm sản trước khi vận chuyển; nếu vận chuyển lâm sản không có hồ sơ hợp pháp sẽ bị xử phạt hành chính và có thể bị tịch thu phương tiện vận chuyển."
  },
  {
    "id": "CBLS_038",
    "question": "Xưởng mộc chế biến gỗ gây tiếng ồn và bụi bặm ảnh hưởng đến khu dân cư xung quanh thì phải làm gì?",
    "options": [
      "Thách thức bà con hàng xóm",
      "Lắp đặt hệ thống hút bụi, tường cách âm và che chắn kín xưởng gia công",
      "Tăng công suất cưa xẻ vào ban đêm",
      "Không cần làm gì vì sản xuất là quyền tự do"
    ],
    "correct": "Lắp đặt hệ thống hút bụi, tường cách âm và che chắn kín xưởng gia công",
    "explanation": "Căn cứ Luật Bảo vệ môi trường và Nghị định số 45/2022/NĐ-CP: Cơ sở chế biến gỗ gây ô nhiễm tiếng ồn, bụi vượt quy chuẩn kỹ thuật môi trường bị xử phạt vi phạm hành chính và buộc áp dụng biện pháp khắc phục tình trạng ô nhiễm."
  },
  {
    "id": "CBLS_039",
    "question": "Việc cất giữ gỗ trong xưởng mộc gia đình có bắt buộc phải lưu hồ sơ nguồn gốc không?",
    "options": [
      "Không cần, gỗ trong nhà riêng là bất khả xâm phạm",
      "Bắt buộc phải có hồ sơ, hóa đơn chứng từ chứng minh nguồn gốc hợp pháp của số gỗ đang cất giữ",
      "Chỉ cần người bán gỗ viết cam đoan miệng",
      "Chỉ cần xưởng gỗ có treo biển hiệu"
    ],
    "correct": "Bắt buộc phải có hồ sơ, hóa đơn chứng từ chứng minh nguồn gốc hợp pháp của số gỗ đang cất giữ",
    "explanation": "Căn cứ Điều 13 và Khoản 7 Điều 32 Thông tư số 26/2025/TT-BNNMT (hợp nhất tại VBHN số 04/VBHN-BNNMT): Lâm sản cất giữ tại cơ sở chế biến, kinh doanh bắt buộc phải có hồ sơ nguồn gốc hợp pháp tương ứng và được ghi chép, theo dõi đầy đủ trong Sổ theo dõi nhập, xuất lâm sản."
  },
  {
    "id": "CBLS_040",
    "question": "Khi cưa xẻ gia công gỗ thuê cho người dân làm nhà, chủ xưởng cưa cần kiểm tra giấy tờ gì?",
    "options": [
      "Không cần kiểm tra gì",
      "Bảng kê lâm sản hoặc giấy tờ xác nhận nguồn gốc gỗ hợp pháp của người thuê cưa",
      "Chỉ cần kiểm tra tiền công trả trước",
      "Kiểm tra sổ đỏ của người thuê cưa"
    ],
    "correct": "Bảng kê lâm sản hoặc giấy tờ xác nhận nguồn gốc gỗ hợp pháp của người thuê cưa",
    "explanation": "Căn cứ Điều 26 và Điều 27 Nghị định số 146/2026/NĐ-CP: Cơ sở cưa xẻ gia công gỗ thuê có trách nhiệm kiểm tra nguồn gốc lâm sản hợp pháp; nếu cưa xẻ gỗ không có hồ sơ hợp pháp sẽ bị xử phạt về hành vi chế biến lâm sản trái pháp luật."
  },
  {
    "id": "CBLS_041",
    "question": "Doanh nghiệp chế biến gỗ có được tự ý xuất khẩu gỗ tròn chưa qua chế biến ra nước ngoài không?",
    "options": [
      "Được tự do xuất khẩu mọi loại gỗ",
      "Nghiêm cấm xuất khẩu gỗ tròn, gỗ xẻ từ rừng tự nhiên trong nước",
      "Chỉ được xuất khẩu qua đường mòn tiểu ngạch",
      "Chỉ cấm xuất khẩu gỗ keo"
    ],
    "correct": "Nghiêm cấm xuất khẩu gỗ tròn, gỗ xẻ từ rừng tự nhiên trong nước",
    "explanation": "Căn cứ Điều 8, Điều 10 Nghị định số 102/2020/NĐ-CP (sửa đổi, bổ sung bởi Nghị định số 120/2024/NĐ-CP) và Điều 12 Thông tư số 26/2025/TT-BNNMT (hợp nhất tại VBHN số 04/VBHN-BNNMT): Gỗ xuất khẩu phải bảo đảm nguồn gốc hợp pháp theo VNTLAS; Nhà nước thực hiện chính sách cấm xuất khẩu gỗ tròn, gỗ xẻ từ rừng tự nhiên trong nước."
  },
  {
    "id": "CBLS_042",
    "question": "Cơ sở mua bán lâm sản khi có thay đổi địa điểm xưởng gỗ hoặc người đại diện thì phải làm gì?",
    "options": [
      "Tự chuyển đi mà không cần báo ai",
      "Thực hiện thủ tục thay đổi đăng ký kinh doanh và thông báo bằng văn bản cho Hạt Kiểm lâm quản lý",
      "Chỉ cần thông báo cho bạn bè trên mạng",
      "Đợi khi nào Kiểm lâm tìm thấy thì mới nói"
    ],
    "correct": "Thực hiện thủ tục thay đổi đăng ký kinh doanh và thông báo bằng văn bản cho Hạt Kiểm lâm quản lý",
    "explanation": "Căn cứ Nghị định số 102/2020/NĐ-CP và các quy định về quản lý ngành nghề kinh doanh chế biến gỗ: Cơ sở chế biến gỗ phải hoạt động đúng quy mô, công suất máy móc thiết bị đã đăng ký và bảo đảm 100% nguồn gốc lâm sản hợp pháp."
  },
  {
    "id": "CBLS_043",
    "question": "Hành vi sử dụng lao động chưa đủ tuổi hoặc không trang bị đồ bảo hộ lao động tại xưởng cưa bị xử lý thế nào?",
    "options": [
      "Được khuyến khích để giảm chi phí",
      "Bị xử phạt nghiêm khắc theo pháp luật về an toàn lao động và bảo hiểm xã hội",
      "Chỉ bị phạt nhắc nhở nếu không xảy ra tai nạn",
      "Không thuộc phạm vi điều chỉnh của luật nào"
    ],
    "correct": "Bị xử phạt nghiêm khắc theo pháp luật về an toàn lao động và bảo hiểm xã hội",
    "explanation": "Căn cứ Bộ luật Lao động, Luật An toàn, vệ sinh lao động và Điều 12 Nghị định số 102/2020/NĐ-CP (sửa đổi bởi NĐ 120/2024/NĐ-CP): Cơ sở chế biến gỗ phải chấp hành quy định an toàn, vệ sinh lao động và độ tuổi lao động; vi phạm sẽ bị xử phạt theo pháp luật lao động và không đủ điều kiện xếp loại Doanh nghiệp Nhóm I."
  },
  {
    "id": "CBLS_044",
    "question": "Chủ xưởng gỗ có được tự ý đun nấu, thắp hương thờ cúng tùy tiện ngay sát bãi gỗ khô không?",
    "options": [
      "Được làm vì tự do tín ngưỡng",
      "Nghiêm cấm vì vi phạm khoảng cách an toàn PCCC, tiềm ẩn nguy cơ phát hỏa thiêu rụi xưởng gỗ",
      "Được làm nếu có xô nước để cạnh",
      "Chỉ cấm vào ban ngày"
    ],
    "correct": "Nghiêm cấm vì vi phạm khoảng cách an toàn PCCC, tiềm ẩn nguy cơ phát hỏa thiêu rụi xưởng gỗ",
    "explanation": "Căn cứ Luật Phòng cháy và chữa cháy và Điều 47 Nghị định số 156/2018/NĐ-CP: Nghiêm cấm mang nguồn lửa, đun nấu hoặc thắp hương thờ cúng tùy tiện tại khu vực có vật liệu gỗ dễ cháy; vi phạm khoảng cách an toàn PCCC bị xử phạt vi phạm hành chính."
  },
  {
    "id": "CBLS_045",
    "question": "Đối với gỗ có nguồn gốc hợp pháp, việc đánh số hiệu lóng gỗ mang lại lợi ích gì cho chủ xưởng?",
    "options": [
      "Để vẽ tranh lên gỗ",
      "Giúp quản lý chính xác từng lóng gỗ, tránh thất thoát và thuận tiện khi xuất trình kiểm tra",
      "Làm giảm giá bán của khúc gỗ",
      "Không có tác dụng gì"
    ],
    "correct": "Giúp quản lý chính xác từng lóng gỗ, tránh thất thoát và thuận tiện khi xuất trình kiểm tra",
    "explanation": "Căn cứ Điều 4 Thông tư số 26/2025/TT-BNNMT (được sửa đổi, bổ sung bởi Thông tư số 84/2025/TT-BNNMT): Việc đánh số hiệu lóng gỗ và lập Bảng kê chi tiết giúp định danh chính xác từng cây/lóng gỗ, phục vụ công tác quản lý và truy xuất nguồn gốc lâm sản hợp pháp."
  },
  {
    "id": "CBLS_046",
    "question": "Chủ xưởng gỗ mua gỗ rừng trồng có hóa đơn chứng từ đầy đủ thì có quyền lợi gì?",
    "options": [
      "Được pháp luật bảo hộ quyền sở hữu, yên tâm sản xuất kinh doanh và dễ dàng vay vốn ngân hàng",
      "Bị Kiểm lâm kiểm tra nhiều hơn xưởng mua gỗ lậu",
      "Không được phép bán ra ngoài tỉnh",
      "Phải đóng phạt thuế tài nguyên"
    ],
    "correct": "Được pháp luật bảo hộ quyền sở hữu, yên tâm sản xuất kinh doanh và dễ dàng vay vốn ngân hàng",
    "explanation": "Căn cứ Luật Lâm nghiệp năm 2017 và Nghị định số 102/2020/NĐ-CP: Lâm sản có nguồn gốc hợp pháp, đầy đủ hóa đơn Bảng kê được Nhà nước bảo hộ quyền tài sản, tạo điều kiện thuận lợi cho cơ sở chế biến trong lưu thông và hội nhập thị trường."
  },
  {
    "id": "CBLS_047",
    "question": "Hành vi nào sau đây bị coi là 'Vận chuyển lâm sản trái pháp luật'?",
    "options": [
      "Chở gỗ có Bảng kê lâm sản và hóa đơn hợp pháp đầy đủ",
      "Vận chuyển gỗ, lâm sản mà không có hồ sơ hợp pháp hoặc hồ sơ không phù hợp với lâm sản thực tế chở trên xe",
      "Chở sản phẩm bàn ghế gỗ hoàn chỉnh có hóa đơn bán lẻ",
      "Chở củi khô của gia đình đun nấu"
    ],
    "correct": "Vận chuyển gỗ, lâm sản mà không có hồ sơ hợp pháp hoặc hồ sơ không phù hợp với lâm sản thực tế chở trên xe",
    "explanation": "Căn cứ Khoản 1 Điều 25 Nghị định số 146/2026/NĐ-CP: Vận chuyển lâm sản trên phương tiện giao thông đường bộ, đường thủy mà không có Bảng kê lâm sản hoặc hồ sơ hợp pháp bị coi là hành vi vận chuyển lâm sản trái pháp luật."
  },
  {
    "id": "CBLS_048",
    "question": "Hành vi 'Quay vòng hồ sơ' (dùng 1 bộ hồ sơ Bảng kê gỗ cũ để chở gỗ lậu nhiều chuyến) bị xử lý thế nào?",
    "options": [
      "Được coi là hành vi thông minh tiết kiệm giấy tờ",
      "Bị xử phạt nghiêm khắc về hành vi vận chuyển lâm sản trái pháp luật và hành vi gian lận hồ sơ lâm sản",
      "Chỉ bị phạt nộp lệ phí cấp lại hồ sơ mới",
      "Không vi phạm nếu hồ sơ chưa hết hạn 1 năm"
    ],
    "correct": "Bị xử phạt nghiêm khắc về hành vi vận chuyển lâm sản trái pháp luật và hành vi gian lận hồ sơ lâm sản",
    "explanation": "Căn cứ Khoản 3 Điều 25 và Điều 27 Nghị định số 146/2026/NĐ-CP: Sử dụng một bộ hồ sơ lâm sản để quay vòng vận chuyển nhiều lần bị xử lý về hành vi vận chuyển lâm sản trái pháp luật và gian lận hồ sơ lâm sản, tịch thu toàn bộ tang vật vi phạm."
  },
  {
    "id": "CBLS_049",
    "question": "Hành vi cất giấu gỗ lậu dưới thùng xe tải rồi phủ rau củ quả hoặc cát đá lên trên nhằm che mắt Kiểm lâm bị coi là gì?",
    "options": [
      "Tình tiết tăng nặng: cất giấu tang vật tinh vi trong vụ vi phạm hành chính lâm nghiệp",
      "Cách bảo quản gỗ không bị nắng nóng",
      "Hành vi hoàn toàn bình thường không ai cấm",
      "Được giảm nhẹ mức phạt vì có chở kèm hàng nông sản"
    ],
    "correct": "Tình tiết tăng nặng: cất giấu tang vật tinh vi trong vụ vi phạm hành chính lâm nghiệp",
    "explanation": "Căn cứ Điểm k Khoản 1 Điều 10 Luật Xử lý vi phạm hành chính: Hành vi cất giấu tang vật tinh vi để trốn tránh sự kiểm tra của lực lượng chức năng là tình tiết tăng nặng khi xem xét áp dụng hình thức xử phạt."
  },
  {
    "id": "CBLS_050",
    "question": "Hành vi cưa xẻ gỗ tròn có nguồn gốc từ việc chặt trộm trong rừng đặc dụng tại xưởng gỗ bị xử lý thế nào?",
    "options": [
      "Chỉ phạt người đi chặt trộm, chủ xưởng xẻ không bị sao",
      "Xử phạt hành vi chế biến lâm sản trái pháp luật, tịch thu toàn bộ gỗ và có thể bị đình chỉ hoạt động xưởng",
      "Được miễn phạt nếu xẻ gỗ vào ban ngày",
      "Chỉ cần trả lại mùn cưa cho Kiểm lâm"
    ],
    "correct": "Xử phạt hành vi chế biến lâm sản trái pháp luật, tịch thu toàn bộ gỗ và có thể bị đình chỉ hoạt động xưởng",
    "explanation": "Căn cứ Điều 26 Nghị định số 146/2026/NĐ-CP: Chế biến lâm sản không có nguồn gốc hợp pháp (gỗ chặt trộm từ rừng đặc dụng) bị phạt tiền, tịch thu toàn bộ lâm sản và có thể bị đình chỉ hoạt động cơ sở chế biến từ 06 đến 12 tháng."
  },
  {
    "id": "CBLS_051",
    "question": "Việc tẩy xóa, sửa chữa số liệu (thể tích, kích thước, tên loài) trên Bảng kê lâm sản bị xử lý thế nào?",
    "options": [
      "Bị xử phạt về hành vi làm sai lệch, gian lận hồ sơ lâm sản hợp pháp",
      "Được tự do sửa nếu dùng bút mực cùng màu",
      "Chỉ bị phạt nếu viết chữ xấu",
      "Không vi phạm nếu chủ hàng tự sửa"
    ],
    "correct": "Bị xử phạt về hành vi làm sai lệch, gian lận hồ sơ lâm sản hợp pháp",
    "explanation": "Điều 27 Nghị định 146/2026/NĐ-CP quy định hành vi tẩy xóa, sửa chữa, làm sai lệch hồ sơ nguồn gốc lâm sản là hành vi vi phạm pháp luật và bị xử phạt tiền từ hàng triệu đến hàng chục triệu đồng."
  },
  {
    "id": "CBLS_052",
    "question": "Hành vi thu mua gỗ quý hiếm Nhóm IA (gỗ sưa, mun, trắc...) trôi nổi không rõ nguồn gốc bị xử lý thế nào?",
    "options": [
      "Không bị phạt nếu mua giá đắt",
      "Bị xử phạt nặng về hành vi tàng trữ lâm sản trái pháp luật và có thể bị khởi tố hình sự nếu khối lượng lớn",
      "Được nhà nước cấp giấy tờ sau khi mua",
      "Chỉ bị phạt nếu đem bán ra nước ngoài"
    ],
    "correct": "Bị xử phạt nặng về hành vi tàng trữ lâm sản trái pháp luật và có thể bị khởi tố hình sự nếu khối lượng lớn",
    "explanation": "Căn cứ Điều 4 Thông tư số 85/2025/TT-BNNMT và Điều 26 Nghị định số 146/2026/NĐ-CP: Gỗ thuộc loài nguy cấp, quý, hiếm Nhóm IA nghiêm cấm khai thác, thương mại vì mục đích thương mại; hành vi thu mua, tàng trữ trái phép bị tịch thu toàn bộ lâm sản và phạt tiền từ 50 triệu đến 500 triệu đồng hoặc truy cứu trách nhiệm hình sự."
  },
  {
    "id": "CBLS_053",
    "question": "Chủ cơ sở chế biến không mở Sổ theo dõi nhập, xuất lâm sản hoặc không ghi chép sổ thì bị xử phạt không?",
    "options": [
      "Không bị phạt vì sổ sách là việc nội bộ",
      "Bị xử phạt vi phạm hành chính về hành vi vi phạm quy định về quản lý hồ sơ lâm sản",
      "Chỉ bị phạt nếu cơ sở bị lỗ vốn",
      "Chỉ bị nhắc nhở bằng lời nói"
    ],
    "correct": "Bị xử phạt vi phạm hành chính về hành vi vi phạm quy định về quản lý hồ sơ lâm sản",
    "explanation": "Điều 27 Nghị định 146/2026/NĐ-CP quy định xử phạt vi phạm hành chính đối với cơ sở chế biến, kinh doanh lâm sản không lập sổ theo dõi hoặc không ghi chép đầy đủ theo quy định."
  },
  {
    "id": "CBLS_054",
    "question": "Hành vi sử dụng con dấu giả hoặc làm giả Bảng kê lâm sản có xác nhận của Kiểm lâm bị xử lý thế nào?",
    "options": [
      "Chỉ bị nhắc nhở nội bộ trong cơ sở chế biến",
      "Bị khởi tố hình sự về tội Làm giả con dấu, tài liệu của cơ quan, tổ chức",
      "Chỉ phải nộp phạt mức cố định 200.000 đồng",
      "Được bỏ qua nếu chủ gỗ chứng minh được gỗ mua từ nước ngoài"
    ],
    "correct": "Bị khởi tố hình sự về tội Làm giả con dấu, tài liệu của cơ quan, tổ chức",
    "explanation": "Hành vi làm giả con dấu của Kiểm lâm hoặc làm giả Bảng kê lâm sản là tội phạm hình sự rất nghiêm trọng theo Điều 341 Bộ luật Hình sự, đối tượng vi phạm bị phạt tù từ 02 đến 07 năm."
  },
  {
    "id": "CBLS_055",
    "question": "Chủ xưởng gỗ cố tình cưa xẻ gỗ vào ban đêm để che giấu hành vi chế biến gỗ lậu thì bị đánh giá thế nào?",
    "options": [
      "Là hành vi chăm chỉ tăng ca lao động",
      "Là tình tiết vi phạm có tính chất lén lút, che giấu hành vi vi phạm",
      "Được miễn các loại thuế đêm",
      "Không ai có quyền can thiệp ban đêm"
    ],
    "correct": "Là tình tiết vi phạm có tính chất lén lút, che giấu hành vi vi phạm",
    "explanation": "Căn cứ Điểm k Khoản 1 Điều 10 Luật Xử lý vi phạm hành chính năm 2012 (sửa đổi, bổ sung 2020): Hành vi lén lút cưa xẻ gỗ lậu vào ban đêm là tình tiết tăng nặng (trốn tránh, che giấu vi phạm hành chính) khi xem xét quyết định xử phạt."
  },
  {
    "id": "CBLS_056",
    "question": "Việc mua bán gỗ qua mạng Internet không có hóa đơn chứng từ, giao nhận hàng tại bìa rừng tiềm ẩn rủi ro gì?",
    "options": [
      "Mua được gỗ giá rất rẻ mà không lo lắng gì",
      "Rủi ro rất cao: dễ mua phải gỗ bất hợp pháp, bị lừa đảo và bị Kiểm lâm tịch thu toàn bộ tiền lẫn gỗ",
      "Được miễn trừ trách nhiệm pháp lý vì mua online",
      "Được ngân hàng hoàn tiền 100%"
    ],
    "correct": "Rủi ro rất cao: dễ mua phải gỗ bất hợp pháp, bị lừa đảo và bị Kiểm lâm tịch thu toàn bộ tiền lẫn gỗ",
    "explanation": "Căn cứ Điều 26 Nghị định số 146/2026/NĐ-CP: Mua bán gỗ trôi nổi qua mạng không có hóa đơn chứng từ bị coi là mua bán lâm sản trái pháp luật; toàn bộ số gỗ bị tịch thu sung quỹ nhà nước và người mua bị phạt tiền."
  },
  {
    "id": "CBLS_057",
    "question": "Mức phạt tiền thấp nhất đối với hành vi vận chuyển lâm sản trái pháp luật khởi điểm từ bao nhiêu?",
    "options": [
      "Từ 50.000 đồng",
      "Từ 1.000.000 đồng trở lên (tùy theo khối lượng, chủng loại lâm sản)",
      "Chỉ phạt nhắc nhở không phạt tiền",
      "Tối thiểu phải từ 50 triệu đồng"
    ],
    "correct": "Từ 1.000.000 đồng trở lên (tùy theo khối lượng, chủng loại lâm sản)",
    "explanation": "Căn cứ Khoản 1 Điều 25 Nghị định số 146/2026/NĐ-CP: Mức phạt tiền thấp nhất đối với hành vi vận chuyển lâm sản trái pháp luật là từ 1.000.000 đồng đến 5.000.000 đồng (áp dụng với gỗ thông thường dưới 01 m³, gỗ Nhóm IIA dưới 0,5 m³, gỗ Nhóm IA dưới 0,1 m³...) và tăng dần theo khối lượng lâm sản vi phạm."
  },
  {
    "id": "CBLS_058",
    "question": "Mức phạt tiền tối đa đối với một cá nhân có hành vi tàng trữ, mua bán, chế biến lâm sản trái phép là bao nhiêu?",
    "options": [
      "100.000.000 đồng",
      "200.000.000 đồng",
      "300.000.000 đồng",
      "500.000.000 đồng (nửa tỷ đồng)"
    ],
    "correct": "500.000.000 đồng (nửa tỷ đồng)",
    "explanation": "Điều 26 Nghị định 146/2026/NĐ-CP quy định mức phạt tiền tối đa đối với cá nhân có hành vi tàng trữ, mua bán, chế biến lâm sản trái pháp luật lên đến 500.000.000 đồng (đối với tổ chức là 1 tỷ đồng)."
  },
  {
    "id": "CBLS_059",
    "question": "Toàn bộ tang vật lâm sản không có hồ sơ hợp pháp bị bắt giữ sẽ bị xử lý như thế nào?",
    "options": [
      "Trả lại cho chủ cơ sở sau khi nộp phạt",
      "Bắt buộc tịch thu toàn bộ sung vào ngân sách nhà nước",
      "Cho phép chủ gỗ tự đem đi bán lấy tiền nộp phạt",
      "Chia cho công nhân xưởng gỗ"
    ],
    "correct": "Bắt buộc tịch thu toàn bộ sung vào ngân sách nhà nước",
    "explanation": "Căn cứ Điều 25 và Điều 26 Nghị định số 146/2026/NĐ-CP: Hình thức xử phạt bổ sung bắt buộc đối với hành vi vận chuyển, mua bán, tàng trữ lâm sản trái pháp luật là tịch thu toàn bộ tang vật lâm sản vi phạm."
  },
  {
    "id": "CBLS_060",
    "question": "Phương tiện giao thông (xe tải, xe bán tải, xe máy) dùng để vận chuyển gỗ lậu bị xử lý thế nào?",
    "options": [
      "Chỉ giữ giấy phép lái xe, trả xe ngay",
      "Bị tịch thu sung công quỹ Nhà nước nếu thuộc trường hợp chở gỗ giá trị lớn hoặc tái phạm",
      "Không bao giờ bị tịch thu xe",
      "Được đổi xe mới nếu nhận lỗi"
    ],
    "correct": "Bị tịch thu sung công quỹ Nhà nước nếu thuộc trường hợp chở gỗ giá trị lớn hoặc tái phạm",
    "explanation": "Điều 25 Nghị định 146/2026/NĐ-CP quy định tịch thu phương tiện vi phạm hành chính đối với các trường hợp vận chuyển lâm sản trái pháp luật có khối lượng lớn hoặc tái phạm nhiều lần."
  },
  {
    "id": "CBLS_061",
    "question": "Tàng trữ, vận chuyển, buôn bán gỗ thông thường trái phép từ bao nhiêu m3 thì bị TRUY CỨU TRÁCH NHIỆM HÌNH SỰ (đi tù)?",
    "options": [
      "Từ 5 m3 trở lên (gỗ tròn) trong mọi trường hợp",
      "Từ 20 m3 trở lên (khung phạt tù từ 06 tháng đến 03 năm)",
      "Phải từ 100 m3 trở lên mới cấu thành tội phạm hình sự",
      "Gỗ thông thường không bao giờ bị xử lý hình sự mà chỉ phạt tiền"
    ],
    "correct": "Từ 20 m3 trở lên (khung phạt tù từ 06 tháng đến 03 năm)",
    "explanation": "Căn cứ Điểm k Khoản 1 Điều 232 Bộ luật Hình sự năm 2015: Hành vi tàng trữ, vận chuyển, chế biến hoặc mua bán trái phép từ 20 m³ đến dưới 40 m³ gỗ thực vật rừng thông thường bị truy cứu trách nhiệm hình sự với khung hình phạt tù từ 06 tháng đến 03 năm; điều luật không phân biệt nguồn gốc rừng tự nhiên hay rừng trồng đối với hành vi tàng trữ, vận chuyển, mua bán."
  },
  {
    "id": "CBLS_062",
    "question": "Theo Nghị định số 146/2026/NĐ-CP, chủ cơ sở chế biến, mua bán lâm sản có hành vi không lập sổ theo dõi hoặc lập sổ không đúng mẫu; không ghi chép hoặc ghi chép không đầy đủ, không đúng thực tế vào sổ nhập, xuất lâm sản thì bị phạt tiền ở khung mức nào?",
    "options": [
      "Phạt tiền từ 10.000.000 đồng đến 20.000.000 đồng",
      "Phạt tiền từ 5.000.000 đồng đến 10.000.000 đồng",
      "Phạt tiền từ 20.000.000 đồng đến 30.000.000 đồng",
      "Phạt tiền từ 1.000.000 đồng đến 5.000.000 đồng"
    ],
    "correct": "Phạt tiền từ 10.000.000 đồng đến 20.000.000 đồng",
    "explanation": "Căn cứ Điểm a Khoản 2 Điều 27 Nghị định số 146/2026/NĐ-CP: Phạt tiền từ 10.000.000 đồng đến 20.000.000 đồng đối với hành vi chủ cơ sở chế biến, mua bán lâm sản không lập sổ theo dõi hoặc lập sổ theo dõi không đúng mẫu theo quy định; không ghi chép hoặc ghi chép không đầy đủ, không đúng thực tế vào sổ nhập, xuất lâm sản."
  },
  {
    "id": "CBLS_063",
    "question": "Theo Bộ luật Hình sự năm 2015 (sửa đổi, bổ sung năm 2017), hành vi tàng trữ, vận chuyển, chế biến hoặc mua bán trái phép gỗ thuộc Danh mục thực vật rừng, động vật rừng nguy cấp, quý, hiếm Nhóm IIA với khối lượng tối thiểu bao nhiêu thì bị truy cứu trách nhiệm hình sự (Điều 232)?",
    "options": [
      "Từ 10 mét khối (m³) trở lên",
      "Từ 1,5 mét khối (m³) trở lên",
      "Từ 20 mét khối (m³) trở lên",
      "Từ 2,5 mét khối (m³) trở lên"
    ],
    "correct": "Từ 10 mét khối (m³) trở lên",
    "explanation": "Căn cứ Điểm k Khoản 1 Điều 232 Bộ luật Hình sự năm 2015 (sửa đổi, bổ sung 2017): Hành vi tàng trữ, vận chuyển, chế biến hoặc mua bán trái phép từ 10 m³ đến dưới 20 m³ gỗ thuộc Danh mục loài nguy cấp, quý, hiếm Nhóm IIA bị truy cứu trách nhiệm hình sự với khung phạt tiền từ 50 đến 300 triệu đồng, phạt cải tạo không giam giữ đến 03 năm hoặc phạt tù từ 06 tháng đến 03 năm."
  },
  {
    "id": "CBLS_064",
    "question": "Ngoài phạt tiền và tịch thu gỗ, cơ sở chế biến gỗ lậu còn có thể bị áp dụng hình thức phạt bổ sung nào?",
    "options": [
      "Buộc phá dỡ toàn bộ nhà ở của chủ xưởng",
      "Đình chỉ hoạt động của cơ sở chế biến lâm sản có thời hạn tối đa đến 12 tháng",
      "Cấm đi khỏi nơi cư trú vĩnh viễn",
      "Buộc phải chuyển nghề sang làm nông nghiệp"
    ],
    "correct": "Đình chỉ hoạt động của cơ sở chế biến lâm sản có thời hạn tối đa đến 12 tháng",
    "explanation": "Điều 26 Nghị định 146/2026/NĐ-CP quy định hình phạt bổ sung: Đình chỉ hoạt động của cơ sở chế biến lâm sản từ 06 tháng đến 12 tháng đối với hành vi chế biến lâm sản trái pháp luật."
  },
  {
    "id": "CBLS_065",
    "question": "Tổ chức (doanh nghiệp, công ty) có hành vi buôn bán gỗ lậu thì mức phạt tiền như thế nào so với cá nhân?",
    "options": [
      "Bằng mức phạt đối với cá nhân",
      "Gấp 02 lần mức phạt tiền đối với cá nhân có cùng hành vi vi phạm",
      "Chỉ bằng 50% mức phạt của cá nhân",
      "Do công ty tự nộp bao nhiêu tùy ý"
    ],
    "correct": "Gấp 02 lần mức phạt tiền đối với cá nhân có cùng hành vi vi phạm",
    "explanation": "Điểm b Khoản 1 Điều 4 Nghị định 146/2026/NĐ-CP quy định mức phạt tiền đối với tổ chức vi phạm hành chính gấp 02 lần mức phạt tiền đối với cá nhân có cùng hành vi vi phạm."
  },
  {
    "id": "CBLS_066",
    "question": "Người mua bán lâm sản lậu có bị tịch thu số tiền bất hợp pháp kiếm được từ việc bán gỗ lậu không?",
    "options": [
      "Được giữ lại toàn bộ số tiền đó",
      "Bắt buộc áp dụng biện pháp khắc phục hậu quả: Buộc nộp lại toàn bộ số lợi bất hợp pháp có được do vi phạm",
      "Chỉ nộp lại 10% tiền lãi",
      "Chỉ nộp lại tiền nếu người mua đòi lại"
    ],
    "correct": "Bắt buộc áp dụng biện pháp khắc phục hậu quả: Buộc nộp lại toàn bộ số lợi bất hợp pháp có được do vi phạm",
    "explanation": "Căn cứ Điểm b Khoản 22 Điều 25 và Điểm b Khoản 22 Điều 26 Nghị định số 146/2026/NĐ-CP: Người có hành vi mua bán lâm sản trái pháp luật buộc phải nộp lại toàn bộ số lợi bất hợp pháp có được vào ngân sách nhà nước."
  },
  {
    "id": "CBLS_067",
    "question": "Trường hợp nào chủ xưởng cưa được coi là có tình tiết giảm nhẹ khi cơ quan chức năng kiểm tra?",
    "options": [
      "Tự nguyện khai báo, thành thật hối lỗi, tích cực phối hợp ngăn chặn hậu quả và giao nộp tang vật",
      "Thuê luật sư đến cãi nhau to tiếng với đoàn kiểm tra",
      "Mang cất giấu nhanh số gỗ còn lại",
      "Bỏ trốn khỏi địa phương"
    ],
    "correct": "Tự nguyện khai báo, thành thật hối lỗi, tích cực phối hợp ngăn chặn hậu quả và giao nộp tang vật",
    "explanation": "Điều 9 Luật Xử lý VPHC quy định người vi phạm tự nguyện khai báo, thành thật hối lỗi, tự nguyện khắc phục hậu quả được áp dụng các tình tiết giảm nhẹ mức phạt theo luật."
  },
  {
    "id": "CBLS_068",
    "question": "Bài học kinh doanh cốt lõi giúp các cơ sở chế biến, vận tải lâm sản phát triển bền vững và không lo bị xử phạt là gì?",
    "options": [
      "Chỉ mua gỗ giá rẻ không cần hỏi giấy tờ",
      "Luôn tuân thủ pháp luật, mua bán gỗ có hóa đơn, Bảng kê hợp pháp và ghi chép sổ sách nhập xuất đầy đủ",
      "Thuê tài xế lái xe chạy thật nhanh vượt trạm",
      "Chỉ chế biến gỗ vào ban đêm để tránh tai mắt"
    ],
    "correct": "Luôn tuân thủ pháp luật, mua bán gỗ có hóa đơn, Bảng kê hợp pháp và ghi chép sổ sách nhập xuất đầy đủ",
    "explanation": "Căn cứ Điều 12 Nghị định số 102/2020/NĐ-CP và Thông tư số 26/2025/TT-BNNMT: Tuân thủ quy chuẩn VNTLAS và lưu giữ đầy đủ hồ sơ nguồn gốc lâm sản là điều kiện bắt buộc giúp cơ sở hoạt động hợp pháp và phát triển bền vững."
  },
  {
    "id": "CBLS_069",
    "question": "Pháp luật lâm nghiệp hiện hành có quy định một bộ hồ sơ thủ tục riêng biệt mang tên 'Hồ sơ cây cổ thụ' hay 'Hồ sơ cây có tuổi thọ cao' không?",
    "options": [
      "KHÔNG quy định riêng đối với 'cây cổ thụ'; việc chứng minh nguồn gốc căn cứ vào nguồn gốc hình thành thực tế của cây (rừng tự nhiên, rừng trồng, đất ngoài lâm nghiệp, công trình dự án)",
      "Có quy định một bộ thủ tục đặc biệt riêng do Bộ Xây dựng ban hành",
      "Mọi cây có tuổi thọ trên 50 năm đều bắt buộc phải đăng ký cây di sản quốc gia mới được mua bán",
      "Chỉ cần giấy xác nhận của Hội Sinh vật cảnh là được coi là hồ sơ cây cổ thụ hợp pháp"
    ],
    "correct": "KHÔNG quy định riêng đối với 'cây cổ thụ'; việc chứng minh nguồn gốc căn cứ vào nguồn gốc hình thành thực tế của cây (rừng tự nhiên, rừng trồng, đất ngoài lâm nghiệp, công trình dự án)",
    "explanation": "Căn cứ Điều 8 Thông tư số 26/2025/TT-BNNMT (được sửa đổi bởi Thông tư số 84/2025/TT-BNNMT): Cây cổ thụ ngoài đất lâm nghiệp quản lý theo quy định về cây phân tán; tính hợp pháp được xác lập qua Bảng kê lâm sản và nguồn gốc đất."
  },
  {
    "id": "CBLS_070",
    "question": "Trường hợp cây cổ thụ, cây bóng mát được di dời từ khu vực thực hiện dự án, công trình xây dựng thì hồ sơ chứng minh nguồn gốc hợp pháp gồm những gì theo Khoản 5 Điều 6 Thông tư 26/2025/TT-BNNMT?",
    "options": [
      "Quyết định hoặc văn bản của cơ quan có thẩm quyền về việc xử lý cây, kèm theo Bảng kê lâm sản và các hồ sơ liên quan khi thực hiện mua bán, vận chuyển",
      "Chỉ cần hợp đồng san lấp mặt bằng của nhà thầu thi công xây dựng",
      "Biên bản họp của ban chỉ huy công trường xây dựng",
      "Giấy cam kết của tài xế xe cẩu chuyên dụng chở cây"
    ],
    "correct": "Quyết định hoặc văn bản của cơ quan có thẩm quyền về việc xử lý cây, kèm theo Bảng kê lâm sản và các hồ sơ liên quan khi thực hiện mua bán, vận chuyển",
    "explanation": "Căn cứ Điểm a Khoản 5 Điều 6, Điều 8 và Điều 11 Thông tư số 26/2025/TT-BNNMT: Hồ sơ lâm sản di dời, khai thác tận dụng từ dự án công trình giải phóng mặt bằng gồm quyết định phê duyệt của cơ quan có thẩm quyền kèm Bảng kê lâm sản và chứng từ lưu thông theo quy định."
  },
  {
    "id": "CBLS_071",
    "question": "Trường hợp cây bứng dưỡng từ khu vực đất ngoài quy hoạch lâm nghiệp, công trình dân dụng đô thị (cây phân tán, loài thông thường) thì hồ sơ chứng minh nguồn gốc căn cứ theo điều khoản nào?",
    "options": [
      "Bảng kê lâm sản do chủ sở hữu lập kèm tài liệu chứng minh quyền sử dụng đất hoặc nguồn gốc hình thành của cây",
      "Hồ sơ xuất nhập khẩu tiểu ngạch biên giới vùng sâu vùng xa",
      "Quy chuẩn kiểm toán tài chính nội bộ của chủ công trình",
      "Không cần bất kỳ hồ sơ nào vì cây nằm ngoài quy hoạch lâm nghiệp"
    ],
    "correct": "Bảng kê lâm sản do chủ sở hữu lập kèm tài liệu chứng minh quyền sử dụng đất hoặc nguồn gốc hình thành của cây",
    "explanation": "Căn cứ Khoản 3 Điều 8 Thông tư số 26/2025/TT-BNNMT (được sửa đổi, bổ sung bởi Thông tư số 84/2025/TT-BNNMT, hợp nhất tại VBHN số 04/VBHN-BNNMT): Cây trồng phân tán, cây vườn nhà loài thông thường do tổ chức, cá nhân, hộ gia đình tự đầu tư thì hồ sơ gồm bản chính Bảng kê lâm sản do chủ lâm sản tự lập (hoặc có xác nhận của cơ quan Kiểm lâm sở tại nếu chủ lâm sản đề nghị xác nhận)."
  },
  {
    "id": "CBLS_072",
    "question": "Cây cảnh cổ thụ mua bán, chuyển nhượng qua nhiều chủ sở hữu trong nước thì hồ sơ nguồn gốc hợp pháp được xác lập như thế nào?",
    "options": [
      "Được kế thừa từ hồ sơ lâm sản của chủ sở hữu trước đó",
      "Tự động mất hiệu lực pháp lý và chủ mới phải làm lại từ đầu từ Ủy ban nhân dân tỉnh",
      "Chỉ cần một bản photocopy căn cước công dân của người chủ đầu tiên",
      "Mỗi lần chuyển nhượng phải đem cây lên trồng lại vào rừng tự nhiên 3 tháng"
    ],
    "correct": "Được kế thừa từ hồ sơ lâm sản của chủ sở hữu trước đó",
    "explanation": "Căn cứ Điều 11 Thông tư số 26/2025/TT-BNNMT (được sửa đổi bởi Thông tư số 84/2025/TT-BNNMT, hợp nhất tại VBHN số 04/VBHN-BNNMT): Hồ sơ lâm sản có tính kế thừa từ chủ sở hữu trước đó, gồm Bảng kê lâm sản (có xác nhận của cơ quan Kiểm lâm sở tại nếu thuộc trường hợp phải xác nhận)."
  },
  {
    "id": "CBLS_073",
    "question": "Trường hợp cây bứng dưỡng thuộc Danh mục loài thực vật rừng nguy cấp, quý, hiếm hoặc Phụ lục CITES (bất kể được bứng từ đâu), hồ sơ nguồn gốc bắt buộc theo quy định nào?",
    "options": [
      "Bắt buộc phải có Bảng kê lâm sản có xác nhận của Cơ quan Kiểm lâm sở tại kèm hồ sơ nguồn gốc hợp pháp",
      "Chỉ cần bản cam kết miệng của người đào cây với người mua",
      "Không cần xác nhận Kiểm lâm nếu cây trồng trong chậu sành",
      "Được phép tự do vận chuyển vào ban đêm để tránh thủ tục hành chính"
    ],
    "correct": "Bắt buộc phải có Bảng kê lâm sản có xác nhận của Cơ quan Kiểm lâm sở tại kèm hồ sơ nguồn gốc hợp pháp",
    "explanation": "Căn cứ Khoản 4 Điều 8 Thông tư số 26/2025/TT-BNNMT (sửa đổi bởi TT 84/2025/TT-BNNMT) và Thông tư số 85/2025/TT-BNNMT: Cây cảnh thuộc loài nguy cấp quý hiếm (Nhóm IA, IIA, CITES) bắt buộc phải có Bảng kê lâm sản có xác nhận của Cơ quan Kiểm lâm sở tại."
  },
  {
    "id": "CBLS_074",
    "question": "Đối với cây cảnh, cây cổ thụ có nguồn gốc nhập khẩu từ nước ngoài lưu thông trong nước, hồ sơ chứng minh nguồn gốc hợp pháp căn cứ vào đâu?",
    "options": [
      "Hồ sơ nhập khẩu hợp pháp (Tờ khai hải quan đã thông quan, Giấy phép CITES nếu loài CITES) và Bảng kê lâm sản khi lưu thông trong nước",
      "Chỉ cần nhãn mác chữ nước ngoài dán trên thân cây",
      "Phiếu chuyển tiền quốc tế qua ứng dụng ngân hàng thương mại",
      "Không cần giấy tờ nếu cây đã trồng sống tại Việt Nam trên 1 năm"
    ],
    "correct": "Hồ sơ nhập khẩu hợp pháp (Tờ khai hải quan đã thông quan, Giấy phép CITES nếu loài CITES) và Bảng kê lâm sản khi lưu thông trong nước",
    "explanation": "Căn cứ Điều 9 Thông tư số 26/2025/TT-BNNMT (được sửa đổi bởi Thông tư số 84/2025/TT-BNNMT): Hồ sơ lâm sản nhập khẩu lưu thông trong nước gồm tờ khai hải quan thông quan và Bảng kê lâm sản hợp lệ."
  },
  {
    "id": "CBLS_075",
    "question": "Khi xác định tính hợp pháp và danh mục quản lý của một loài cây gỗ, cây cảnh, căn cứ pháp lý chính thức duy nhất là gì?",
    "options": [
      "Tên khoa học (tên Latinh) của loài; tên gọi thông thường bằng tiếng Việt hoặc tiếng Anh chỉ có giá trị tham khảo",
      "Tên mỹ miều do giới chơi cây cảnh tự phong đặt",
      "Tên theo bảng báo giá của các công ty cây xanh đô thị",
      "Tên cây ghi trong các bài thơ dân gian cổ điển"
    ],
    "correct": "Tên khoa học (tên Latinh) của loài; tên gọi thông thường bằng tiếng Việt hoặc tiếng Anh chỉ có giá trị tham khảo",
    "explanation": "Căn cứ Điều 4 Thông tư số 85/2025/TT-BNNMT và Thông tư số 26/2025/TT-BNNMT (sửa đổi bởi Thông tư số 84/2025/TT-BNNMT): Tên khoa học (tên Latinh) là căn cứ pháp lý chính thức duy nhất xác định loài cây gỗ trong quản lý và truy xuất nguồn gốc."
  },
  {
    "id": "CBLS_076",
    "question": "Hộ gia đình, cá nhân có cây cảnh vườn nhà thuộc loài nguy cấp, quý, hiếm (như thông đỏ, hoàng đàn...) khi khai thác cần lập Phương án khai thác theo mẫu nào?",
    "options": [
      "Phương án khai thác lập theo Mẫu số 08 Phụ lục II",
      "Bản thiết kế kỹ thuật xây dựng nhà cấp 4",
      "Hợp đồng thuê nhân công bốc vác thời vụ",
      "Phương án sản xuất nông nghiệp công nghệ cao"
    ],
    "correct": "Phương án khai thác lập theo Mẫu số 08 Phụ lục II",
    "explanation": "Căn cứ Điểm c Khoản 1 và Điểm b Khoản 4 Điều 6 Thông tư số 26/2025/TT-BNNMT (hợp nhất tại VBHN số 04/VBHN-BNNMT): Phương án khai thác của hộ gia đình, cá nhân, cộng đồng dân cư được lập theo Mẫu số 08 Phụ lục II ban hành kèm theo Thông tư."
  },
  {
    "id": "CBLS_077",
    "question": "Tình huống: Doanh nghiệp X trúng gói thầu giải tỏa mặt bằng dự án hồ chứa nước, trong lòng hồ có 5 cây đa cổ thụ. Doanh nghiệp X bứng 5 cây đa này chở đi bán cho khu du lịch thì hồ sơ cần những gì?",
    "options": [
      "Văn bản hoặc Quyết định xử lý cây của cấp có thẩm quyền phê duyệt dự án kèm Bảng kê lâm sản hợp lệ khi lưu thông",
      "Chỉ cần hợp đồng trúng thầu thi công xây lắp hồ chứa nước",
      "Chỉ cần nộp tiền thuế tài nguyên tại kho bạc khu vực",
      "Không cần giấy tờ gì vì cây nằm trong lòng hồ sắp bị ngập nước"
    ],
    "correct": "Văn bản hoặc Quyết định xử lý cây của cấp có thẩm quyền phê duyệt dự án kèm Bảng kê lâm sản hợp lệ khi lưu thông",
    "explanation": "Căn cứ Điểm a Khoản 5 Điều 6, Điều 8 và Điều 11 Thông tư số 26/2025/TT-BNNMT (hợp nhất tại VBHN số 04/VBHN-BNNMT): Cây khai thác tận dụng từ giải phóng mặt bằng lòng hồ dự án cần văn bản, quyết định phê duyệt của cấp có thẩm quyền kèm Bảng kê lâm sản và chứng từ mua bán, vận chuyển hợp pháp."
  },
  {
    "id": "CBLS_078",
    "question": "Tình huống: Anh B mua một cây si cổ thụ có tuổi thọ hàng trăm năm đào từ vườn nhà của ông H ở xã bên cạnh mang về vườn ươm. Anh B cần lưu giữ hồ sơ gì để chứng minh nguồn gốc hợp pháp?",
    "options": [
      "Bảng kê lâm sản do ông H lập kèm tài liệu chứng minh quyền sử dụng đất/nguồn gốc vườn nhà của ông H và văn bản mua bán/chuyển nhượng giữa hai bên",
      "Chỉ cần một đoạn ghi âm cuộc điện thoại thỏa thuận giá cả giữa anh B và ông H",
      "Bản photocopy sổ hộ khẩu của ông H có đóng dấu giáp lai",
      "Chỉ cần giấy biên nhận cọc tiền có chữ ký của người làm chứng"
    ],
    "correct": "Bảng kê lâm sản do ông H lập kèm tài liệu chứng minh quyền sử dụng đất/nguồn gốc vườn nhà của ông H và văn bản mua bán/chuyển nhượng giữa hai bên",
    "explanation": "Căn cứ Điều 8 Thông tư số 26/2025/TT-BNNMT (được sửa đổi bởi Thông tư số 84/2025/TT-BNNMT): Cây mua từ vườn nhà cần Bảng kê lâm sản của chủ cũ, chứng từ chứng minh đất ở và văn bản mua bán chuyển nhượng hợp pháp."
  },
  {
    "id": "CBLS_079",
    "question": "Tổ chức, hộ kinh doanh cây cảnh, gỗ chế biến phải lập và ghi chép Sổ theo dõi nhập, xuất lâm sản theo mẫu nào và xuất trình khi nào?",
    "options": [
      "Lập Sổ theo dõi nhập, xuất lâm sản (Mẫu số 04), cập nhật đầy đủ, kịp thời và xuất trình khi có yêu cầu kiểm tra",
      "Ghi chép vào sổ nhật ký cá nhân và chỉ cho người thân xem",
      "Không phải lập sổ nếu đã nộp thuế khoán hàng tháng cho cơ quan thuế",
      "Chỉ cần lập sổ nếu có quy mô vốn kinh doanh trên 10 tỷ đồng"
    ],
    "correct": "Lập Sổ theo dõi nhập, xuất lâm sản (Mẫu số 04), cập nhật đầy đủ, kịp thời và xuất trình khi có yêu cầu kiểm tra",
    "explanation": "Căn cứ Điểm c Khoản 7 Điều 32 Thông tư số 26/2025/TT-BNNMT (được sửa đổi bởi Thông tư số 84/2025/TT-BNNMT): Cơ sở kinh doanh phải lập Sổ theo dõi nhập, xuất lâm sản (Mẫu số 04), cập nhật đầy đủ, kịp thời và xuất trình khi có yêu cầu kiểm tra."
  },
  {
    "id": "CBLS_080",
    "question": "Theo Thông tư số 26/2025/TT-BNNMT (được sửa đổi, bổ sung bởi Thông tư số 84/2025/TT-BNNMT), trường hợp cần xác minh nguồn gốc lâm sản trước khi xác nhận Bảng kê lâm sản mà vụ việc có nhiều nội dung phức tạp thì thời hạn xác minh và xác nhận tối đa là bao lâu?",
    "options": [
      "Không quá 03 ngày làm việc kể từ ngày thông báo",
      "Không quá 02 ngày làm việc kể từ ngày thông báo",
      "Không quá 05 ngày làm việc kể từ ngày tiếp nhận hồ sơ",
      "Không quá 10 ngày làm việc kể từ ngày nhận đủ hồ sơ hợp lệ"
    ],
    "correct": "Không quá 03 ngày làm việc kể từ ngày thông báo",
    "explanation": "Căn cứ Điểm c Khoản 7 Điều 5 Thông tư số 26/2025/TT-BNNMT (được sửa đổi bởi Thông tư số 84/2025/TT-BNNMT, hợp nhất tại VBHN số 04/VBHN-BNNMT): Khi cần xác minh nguồn gốc lâm sản, Kiểm lâm tiến hành xác minh trong thời hạn 02 ngày làm việc kể từ ngày thông báo; trường hợp có nhiều nội dung phức tạp, việc xác minh và xác nhận được thực hiện không quá 03 ngày làm việc."
  },
  {
    "id": "CBLS_081",
    "question": "Hành vi đào trộm cây gỗ cổ thụ, cây cảnh trên núi đá thuộc rừng phòng hộ, rừng đặc dụng đem về bán cho các khu nghỉ dưỡng bị xử lý như thế nào?",
    "options": [
      "Bị xử lý nghiêm khắc về hành vi khai thác, tàng trữ lâm sản trái pháp luật hoặc bị truy cứu trách nhiệm hình sự và tịch thu tang vật",
      "Được coi là hoạt động khai hoang tôn tạo cảnh quan thiên nhiên",
      "Chỉ bị phạt vi phạm hành chính 200.000 đồng nếu cây trồng lại vẫn sống tốt",
      "Được cấp giấy chứng nhận nguồn gốc nếu nộp đơn tự thú trong 30 ngày"
    ],
    "correct": "Bị xử lý nghiêm khắc về hành vi khai thác, tàng trữ lâm sản trái pháp luật hoặc bị truy cứu trách nhiệm hình sự và tịch thu tang vật",
    "explanation": "Căn cứ Điều 232 và Điều 243 Bộ luật Hình sự năm 2015: Đào trộm cây gỗ cổ thụ rừng tự nhiên cấu thành tội khai thác rừng trái phép hoặc hủy hoại rừng, bị xử lý hình sự."
  },
  {
    "id": "CBLS_082",
    "question": "Thời hạn lưu giữ hồ sơ lâm sản tại các cơ sở kinh doanh, chế biến lâm sản, cây cảnh theo quy định là bao lâu?",
    "options": [
      "Tối thiểu 05 năm kể từ ngày lập hồ sơ hoặc xuất bán hết toàn bộ lô lâm sản",
      "Chỉ cần lưu giữ trong thời gian 06 tháng kể từ ngày giao hàng",
      "Hết năm tài chính được phép tiêu hủy toàn bộ hồ sơ sổ sách",
      "Không bắt buộc lưu giữ nếu cơ sở đã chụp ảnh lưu vào điện thoại"
    ],
    "correct": "Tối thiểu 05 năm kể từ ngày lập hồ sơ hoặc xuất bán hết toàn bộ lô lâm sản",
    "explanation": "Căn cứ Điểm b Khoản 5 Điều 27 Nghị định số 102/2020/NĐ-CP (được sửa đổi bởi Nghị định 120/2024/NĐ-CP) và Khoản 7 Điều 32 Thông tư số 26/2025/TT-BNNMT (hợp nhất tại VBHN số 04/VBHN-BNNMT): Chủ cơ sở chế biến, kinh doanh có trách nhiệm lưu giữ đầy đủ hồ sơ lâm sản trong thời hạn 05 năm kể từ ngày xuất bán gỗ."
  },
  {
    "id": "CBLS_083",
    "question": "Theo Nghị định số 102/2020/NĐ-CP (được sửa đổi, bổ sung bởi Nghị định số 120/2024/NĐ-CP), doanh nghiệp chế biến, xuất khẩu gỗ phải đáp ứng tiêu chí hoạt động liên tục trong thời gian tối thiểu bao lâu kể từ ngày đăng ký thành lập để được xem xét phân loại là Doanh nghiệp Nhóm I?",
    "options": [
      "Ít nhất 01 năm kể từ ngày đăng ký thành lập doanh nghiệp",
      "Ít nhất 02 năm kể từ ngày đăng ký thành lập doanh nghiệp",
      "Ít nhất 06 tháng kể từ ngày bắt đầu hoạt động sản xuất kinh doanh",
      "Ít nhất 03 năm kể từ ngày được cấp mã số thuế doanh nghiệp"
    ],
    "correct": "Ít nhất 01 năm kể từ ngày đăng ký thành lập doanh nghiệp",
    "explanation": "Căn cứ Điểm a Khoản 1 Điều 12 Nghị định số 102/2020/NĐ-CP (được sửa đổi, bổ sung bởi Nghị định số 120/2024/NĐ-CP và Nghị định số 42/2026/NĐ-CP): Doanh nghiệp Nhóm I là doanh nghiệp tuân thủ đầy đủ quy định của pháp luật trong việc thành lập và hoạt động ít nhất 01 năm kể từ ngày đăng ký thành lập doanh nghiệp, tuân thủ quy định bảo đảm gỗ hợp pháp và chế độ báo cáo, lưu giữ hồ sơ."
  },
  {
    "id": "CBLS_084",
    "question": "Tình huống: Nghệ nhân K mua một gốc cây gỗ lũa từ người đi rừng về đục tượng bán 80 triệu đồng. Khi vận chuyển đi giao cho khách, anh K bị Kiểm lâm kiểm tra. Để chuyến hàng hợp pháp, anh K cần xuất trình gì?",
    "options": [
      "Hóa đơn bán hàng hoặc chứng từ hợp pháp kèm Bảng kê lâm sản do anh K tự lập khi lưu thông sản phẩm gỗ",
      "Chỉ cần bản vẽ thiết kế tác phẩm mỹ nghệ của anh K",
      "Giấy chứng nhận danh hiệu nghệ nhân làng nghề",
      "Không cần giấy tờ gì vì gỗ lũa đã được đục thành tác phẩm nghệ thuật"
    ],
    "correct": "Hóa đơn bán hàng hoặc chứng từ hợp pháp kèm Bảng kê lâm sản do anh K tự lập khi lưu thông sản phẩm gỗ",
    "explanation": "Căn cứ Khoản 4 Điều 5 và Điều 11 Thông tư số 26/2025/TT-BNNMT (hợp nhất tại VBHN số 04/VBHN-BNNMT): Sản phẩm gỗ mỹ nghệ hoàn chỉnh không phải xác nhận Bảng kê lâm sản; khi lưu thông nội địa cần hóa đơn hoặc chứng từ bán hàng hợp pháp kèm Bảng kê lâm sản do chủ hàng tự lập."
  },
  {
    "id": "CBLS_085",
    "question": "Theo Thông tư số 26/2025/TT-BNNMT (được sửa đổi, bổ sung bởi Thông tư số 84/2025/TT-BNNMT), thời gian chốt số liệu báo cáo định kỳ hằng năm về tình hình nhập, xuất lâm sản của tổ chức, hộ kinh doanh gửi cơ quan Kiểm lâm sở tại được tính như thế nào?",
    "options": [
      "Tính từ ngày 15 tháng 12 năm trước kỳ báo cáo đến ngày 14 tháng 12 của kỳ báo cáo",
      "Tính từ ngày 01 tháng 01 đến ngày 31 tháng 12 của năm thực hiện báo cáo",
      "Tính từ ngày 15 tháng 01 năm trước kỳ báo cáo đến ngày 14 tháng 01 của kỳ báo cáo",
      "Tính từ ngày 01 tháng 12 năm trước kỳ báo cáo đến ngày 30 tháng 11 của kỳ báo cáo"
    ],
    "correct": "Tính từ ngày 15 tháng 12 năm trước kỳ báo cáo đến ngày 14 tháng 12 của kỳ báo cáo",
    "explanation": "Căn cứ Điểm c Khoản 7 Điều 32 Thông tư số 26/2025/TT-BNNMT (được sửa đổi, bổ sung bởi Thông tư số 84/2025/TT-BNNMT, hợp nhất tại VBHN số 04/VBHN-BNNMT): Tổ chức, hộ kinh doanh báo cáo tình hình nhập, xuất lâm sản cho cơ quan Kiểm lâm sở tại theo Mẫu số 29 Phụ lục II định kỳ hằng năm trước ngày 15 tháng 01. Thời gian chốt số liệu báo cáo được tính từ ngày 15 tháng 12 năm trước kỳ báo cáo đến ngày 14 tháng 12 của kỳ báo cáo (trừ trường hợp đã cập nhật trên hệ thống quản lý, truy xuất nguồn gốc lâm sản điện tử)."
  },
  {
    "id": "CBLS_086",
    "question": "Tình huống: Ông A khai thác vườn keo sản xuất do gia đình tự trồng, có các lóng gỗ đã cắt khúc dài từ 1 mét trở lên. Theo Thông tư số 26/2025/TT-BNNMT (sửa đổi bởi TT 84/2025/TT-BNNMT), những lóng gỗ keo có đường kính đầu nhỏ từ bao nhiêu centimét (cm) trở lên thì được xác định là gỗ tròn?",
    "options": [
      "Từ 06 cm trở lên",
      "Từ 10 cm trở lên",
      "Từ 20 cm trở lên",
      "Từ 05 cm trở lên"
    ],
    "correct": "Từ 06 cm trở lên",
    "explanation": "Căn cứ Điểm c Khoản 2 Điều 3 Thông tư số 26/2025/TT-BNNMT (hợp nhất tại VBHN số 04/VBHN-BNNMT): Gỗ tròn là gỗ nguyên khai, còn nguyên hình dạng sau khai thác chưa cắt khúc hoặc đã cắt khúc, gỗ bóc vỏ, gỗ lóc lõi có kích thước: 'Gỗ rừng trồng, rừng tràm, rừng ngập mặn có đường kính đầu nhỏ từ 06 cm trở lên và chiều dài từ 01 m trở lên'."
  },
  {
    "id": "CBLS_087",
    "question": "Tình huống: Hộ gia đình bà B tận thu gốc, rễ cây keo và cành ngọn sau khai thác rừng trồng của gia đình để bán cho xưởng băm dăm. Do gỗ có hình thù phức tạp, không đo được kích thước nên bà B cân được 3.000 kg. Theo Thông tư số 26/2025/TT-BNNMT, khối lượng này được quy đổi tương đương bằng bao nhiêu mét khối (m³) gỗ tròn?",
    "options": [
      "Quy đổi bằng 03 m³ gỗ tròn (1.000 kg bằng 01 m³ gỗ tròn)",
      "Quy đổi bằng 2,1 m³ gỗ tròn (áp dụng hệ số quy đổi 0,7)",
      "Quy đổi bằng 1,5 m³ gỗ tròn (áp dụng tỷ lệ 2.000 kg bằng 01 m³)",
      "Không được quy đổi sang mét khối mà bắt buộc chỉ ghi đơn vị kg"
    ],
    "correct": "Quy đổi bằng 03 m³ gỗ tròn (1.000 kg bằng 01 m³ gỗ tròn)",
    "explanation": "Căn cứ Khoản 3 Điều 4 Thông tư số 26/2025/TT-BNNMT (hợp nhất tại VBHN số 04/VBHN-BNNMT): Đối với gỗ gốc, rễ; gỗ có hình thù phức tạp, không đồng nhất; gỗ không thể đo được kích thước thì thực hiện cân, đơn vị tính là kilôgam (kg) hoặc tính theo ster; quy đổi 1000 kg bằng 01 m³ gỗ tròn hoặc quy đổi 01 ster bằng 0,7 m³ gỗ tròn."
  },
  {
    "id": "CBLS_088",
    "question": "Tình huống: Anh C là chủ xưởng mộc gia đình cưa xẻ gỗ hộp loài thông thường để bán cho người dân làm nhà. Theo Thông tư số 26/2025/TT-BNNMT (sửa đổi bởi TT 84/2025/TT-BNNMT), hộp gỗ xẻ có kích thước như thế nào thì anh C bắt buộc phải đánh số hiệu gỗ bằng sơn vào mặt cắt ngang hai đầu hộp gỗ?",
    "options": [
      "Chiều dài từ 01 m trở lên, chiều rộng từ 20 cm trở lên và chiều dày từ 05 cm trở lên",
      "Chiều dài từ 02 m trở lên, chiều rộng từ 30 cm trở lên và chiều dày từ 10 cm trở lên",
      "Bắt buộc đánh số hiệu đối với mọi kích thước gỗ xẻ không phân biệt lớn nhỏ",
      "Chỉ bắt buộc đánh số hiệu đối với gỗ hộp có chiều dài từ 03 m trở lên"
    ],
    "correct": "Chiều dài từ 01 m trở lên, chiều rộng từ 20 cm trở lên và chiều dày từ 05 cm trở lên",
    "explanation": "Căn cứ Khoản 7 Điều 4 Thông tư số 26/2025/TT-BNNMT (hợp nhất tại VBHN số 04/VBHN-BNNMT): Chủ lâm sản hoặc cơ quan chức năng phải thực hiện đánh số hiệu đầu lóng, khúc, hộp, thanh, tấm gỗ đối với gỗ xẻ, gỗ đẽo có chiều dài từ 1 m trở lên, chiều rộng từ 20 cm trở lên, chiều dày từ 5 cm trở lên; số hiệu gỗ đánh bằng chữ Ả Rập, được ghi vào mặt cắt ngang hai đầu lóng gỗ, hộp gỗ và sử dụng sơn có màu sắc khác với màu của gỗ."
  },
  {
    "id": "CBLS_089",
    "question": "Tình huống: Ông D khai thác xong vườn cây keo do gia đình tự đầu tư và chuẩn bị bốc xếp lên xe ô tô tải xuất bán toàn bộ cho một xưởng chế biến trong một chuyến hàng. Theo Thông tư số 26/2025/TT-BNNMT, ông D phải lập Bảng kê lâm sản khi nào và theo mẫu số mấy?",
    "options": [
      "Lập khi bán, chuyển giao quyền sở hữu, vận chuyển lâm sản trong cùng một lần theo Mẫu số 01 Phụ lục II",
      "Chỉ lập sau khi xưởng chế biến đã cân và thanh toán xong toàn bộ tiền gỗ",
      "Lập theo Mẫu số 02 Phụ lục II áp dụng cho mọi trường hợp gỗ rừng trồng",
      "Không cần lập Bảng kê nếu đã có hợp đồng mua bán viết tay giữa hai bên"
    ],
    "correct": "Lập khi bán, chuyển giao quyền sở hữu, vận chuyển lâm sản trong cùng một lần theo Mẫu số 01 Phụ lục II",
    "explanation": "Căn cứ Điểm b Khoản 1 và Khoản 2 Điều 5 Thông tư số 26/2025/TT-BNNMT (sửa đổi, bổ sung bởi Thông tư số 84/2025/TT-BNNMT, hợp nhất tại VBHN số 04/VBHN-BNNMT): Chủ lâm sản lập Bảng kê lâm sản khi bán, chuyển giao quyền sở hữu, vận chuyển lâm sản trong cùng một lần theo Mẫu số 01 Phụ lục II ban hành kèm theo Thông tư này."
  },
  {
    "id": "CBLS_090",
    "question": "Tình huống: Hộ gia đình ông M chặt hạ một số cây xoan đào và mít trong vườn nhà do gia đình tự trồng để xuất bán cho thợ mộc đóng đồ gia dụng. Theo Thông tư số 26/2025/TT-BNNMT (sửa đổi bởi TT 84/2025/TT-BNNMT), hồ sơ lâm sản hợp pháp do gia đình ông M lập giao cho người mua gồm tài liệu gì?",
    "options": [
      "Bản chính Bảng kê lâm sản do ông M tự lập (hoặc có xác nhận của Kiểm lâm nếu ông M đề nghị)",
      "Bắt buộc phải có Giấy phép khai thác gỗ vườn nhà do Ủy ban nhân dân cấp xã cấp",
      "Bắt buộc phải có Biên bản kiểm tra thực địa và phê duyệt của Hạt Kiểm lâm trước khi chặt",
      "Chỉ cần giấy viết tay biên nhận tiền giữa ông M và người mua không cần lập Bảng kê"
    ],
    "correct": "Bản chính Bảng kê lâm sản do ông M tự lập (hoặc có xác nhận của Kiểm lâm nếu ông M đề nghị)",
    "explanation": "Căn cứ Khoản 3 Điều 8 Thông tư số 26/2025/TT-BNNMT (hợp nhất tại VBHN số 04/VBHN-BNNMT): Gỗ loài thông thường khai thác từ rừng sản xuất là rừng trồng, gỗ có tên trùng với cây gỗ rừng tự nhiên, cây trồng phân tán, cây vườn nhà do tổ chức, cá nhân, hộ gia đình tự đầu tư: bản chính Bảng kê lâm sản do chủ lâm sản lập hoặc bản chính Bảng kê lâm sản có xác nhận của cơ quan Kiểm lâm sở tại đối với trường hợp chủ lâm sản đề nghị xác nhận."
  },
  {
    "id": "CBLS_091",
    "question": "Tình huống: Gia đình anh P khai thác gỗ rừng trồng sản xuất của mình, sau đó tự dùng xe ô tô tải gia đình chở gỗ từ đồi rừng về tập kết tại bãi gỗ cạnh nhà trong cùng một lần và cùng một phương tiện. Theo Thông tư số 26/2025/TT-BNNMT, hồ sơ lâm sản đi đường thực hiện như thế nào?",
    "options": [
      "Thực hiện theo quy định tại Điều 8 Thông tư này (mang theo bản chính Bảng kê lâm sản do anh P tự lập)",
      "Bắt buộc phải xin Giấy phép vận chuyển đặc biệt của cơ quan Kiểm lâm sở tại trước khi chuyển",
      "Bắt buộc phải có hóa đơn giá trị gia tăng kèm theo ngay từ khi chở ra khỏi đồi rừng",
      "Không cần mang theo bất kỳ giấy tờ gì và không bị giới hạn số lần, phương tiện vận chuyển"
    ],
    "correct": "Thực hiện theo quy định tại Điều 8 Thông tư này (mang theo bản chính Bảng kê lâm sản do anh P tự lập)",
    "explanation": "Căn cứ Khoản 3 Điều 11 Thông tư số 26/2025/TT-BNNMT (hợp nhất tại VBHN số 04/VBHN-BNNMT): Đối với lâm sản sau khai thác do chủ lâm sản vận chuyển về kho, bãi trong cùng một lần và cùng một phương tiện: thực hiện theo quy định tại Điều 8 Thông tư này (bản chính Bảng kê lâm sản do chủ lâm sản lập)."
  },
  {
    "id": "CBLS_092",
    "question": "Tình huống: Hộ kinh doanh xưởng mộc của ông T thu mua gỗ keo tròn từ các hộ dân trồng rừng trong huyện về xẻ làm cốt pha và đóng đồ mộc dân dụng. Theo Thông tư số 26/2025/TT-BNNMT (sửa đổi bởi TT 84/2025/TT-BNNMT), hồ sơ lâm sản bắt buộc phải có và lưu giữ tại cơ sở chế biến của ông T gồm những gì?",
    "options": [
      "Bản chính Bảng kê lâm sản của người bán giao, Sổ theo dõi nhập xuất lâm sản (Mẫu số 04) và bản sao hồ sơ khi xuất bán",
      "Chỉ cần lưu giữ chứng từ thanh toán tiền mặt qua ngân hàng giữa bên mua và bên bán",
      "Chỉ cần lưu Sổ nhật ký chi tiêu gia đình và hóa đơn tiền điện sản xuất của xưởng mộc",
      "Không phải lưu giữ hồ sơ hay sổ sách nếu chỉ cưa xẻ gỗ cho người dân trong cùng xã"
    ],
    "correct": "Bản chính Bảng kê lâm sản của người bán giao, Sổ theo dõi nhập xuất lâm sản (Mẫu số 04) và bản sao hồ sơ khi xuất bán",
    "explanation": "Căn cứ Điểm b, Điểm c và Điểm d Khoản 1 Điều 13 Thông tư số 26/2025/TT-BNNMT (sửa đổi bởi Thông tư số 84/2025/TT-BNNMT, hợp nhất tại VBHN số 04/VBHN-BNNMT): Hồ sơ lâm sản tại cơ sở chế biến, kinh doanh gồm: Bản chính Bảng kê lâm sản và bản sao hồ sơ lâm sản chuyển giao quyền sở hữu từ tổ chức, cá nhân liền kề trước đó; Bản sao hồ sơ lâm sản khi xuất bán; Sổ theo dõi nhập, xuất lâm sản đối với tổ chức, hộ kinh doanh theo Mẫu số 04 Phụ lục II."
  }
];

if (typeof module !== 'undefined' && module.exports) {
    module.exports = question_CBLS;
}
